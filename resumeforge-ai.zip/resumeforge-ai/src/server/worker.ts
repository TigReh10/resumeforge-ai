import 'dotenv/config'
import { Worker } from 'bullmq'
import { AI_QUEUE, type AiJobData } from '@/lib/queue'
import { redis } from '@/lib/redis'
import { prisma } from '@/lib/prisma'
import { runByType } from '@/lib/services/analysis'
import { logger } from '@/lib/logger'

/**
 * Standalone worker process for heavy AI jobs. Run with: npm run worker
 * Horizontally scalable — start N replicas; BullMQ distributes work.
 */
const concurrency = Number(process.env.WORKER_CONCURRENCY ?? 5)

const worker = new Worker<AiJobData>(
  AI_QUEUE,
  async (job) => {
    const { aiJobId, userId, plan, type, payload } = job.data
    await prisma.aiJob.update({
      where: { id: aiJobId },
      data: { status: 'PROCESSING', attempts: { increment: 1 } },
    })
    try {
      const result = await runByType({ type, userId, plan, payload })
      await prisma.aiJob.update({
        where: { id: aiJobId },
        data: { status: 'COMPLETED', result: result as object },
      })
      return result
    } catch (err) {
      logger.error({ err, aiJobId }, 'AI job failed')
      await prisma.aiJob.update({
        where: { id: aiJobId },
        data: { status: 'FAILED', error: (err as Error).message },
      })
      throw err
    }
  },
  { connection: redis, concurrency },
)

worker.on('completed', (job) => logger.info({ jobId: job.id }, 'AI job completed'))
worker.on('failed', (job, err) => logger.error({ jobId: job?.id, err }, 'AI job failed (final)'))

logger.info({ concurrency }, 'AI worker started')

process.on('SIGTERM', async () => {
  await worker.close()
  process.exit(0)
})
