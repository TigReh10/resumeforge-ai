import * as React from 'react'
import { cn } from '@/lib/utils'

export function Progress({ value = 0, className }: { value?: number; className?: string }) {
  const clamped = Math.max(0, Math.min(100, value))
  const color = clamped >= 80 ? 'bg-emerald-500' : clamped >= 60 ? 'bg-amber-500' : 'bg-rose-500'
  return (
    <div className={cn('h-2.5 w-full overflow-hidden rounded-full bg-secondary', className)}>
      <div className={cn('h-full rounded-full transition-all', color)} style={{ width: `${clamped}%` }} />
    </div>
  )
}
