'use client'

import * as React from 'react'
import { create } from 'zustand'
import { cn } from '@/lib/utils'

type Toast = { id: string; title: string; description?: string; variant?: 'default' | 'success' | 'error' }

type ToastStore = {
  toasts: Toast[]
  push: (t: Omit<Toast, 'id'>) => void
  dismiss: (id: string) => void
}

export const useToast = create<ToastStore>((set) => ({
  toasts: [],
  push: (t) => {
    const id = Math.random().toString(36).slice(2)
    set((s) => ({ toasts: [...s.toasts, { ...t, id }] }))
    setTimeout(() => set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) })), 4000)
  },
  dismiss: (id) => set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) })),
}))

export function Toaster() {
  const { toasts, dismiss } = useToast()
  return (
    <div className="fixed bottom-4 right-4 z-50 flex w-80 flex-col gap-2">
      {toasts.map((t) => (
        <div
          key={t.id}
          onClick={() => dismiss(t.id)}
          className={cn(
            'cursor-pointer rounded-lg border bg-card p-4 shadow-lg',
            t.variant === 'success' && 'border-emerald-500/40',
            t.variant === 'error' && 'border-destructive/40',
          )}
        >
          <p className="text-sm font-semibold">{t.title}</p>
          {t.description && <p className="mt-1 text-xs text-muted-foreground">{t.description}</p>}
        </div>
      ))}
    </div>
  )
}
