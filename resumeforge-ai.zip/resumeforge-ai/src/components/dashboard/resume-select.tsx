'use client'

import { useQuery } from '@tanstack/react-query'
import { api } from '@/lib/api-client'

type Resume = { id: string; title: string }

export function ResumeSelect({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const { data } = useQuery({ queryKey: ['resumes'], queryFn: () => api.get<Resume[]>('/resumes') })
  return (
    <select
      className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
      value={value}
      onChange={(e) => onChange(e.target.value)}
    >
      <option value="">Select a resume…</option>
      {data?.map((r) => (
        <option key={r.id} value={r.id}>{r.title}</option>
      ))}
    </select>
  )
}

type Job = { id: string; title: string; company?: string }

export function JobSelect({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const { data } = useQuery({ queryKey: ['jobs'], queryFn: () => api.get<Job[]>('/jobs') })
  return (
    <select
      className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
      value={value}
      onChange={(e) => onChange(e.target.value)}
    >
      <option value="">Select a job posting…</option>
      {data?.map((j) => (
        <option key={j.id} value={j.id}>{j.title}{j.company ? ` — ${j.company}` : ''}</option>
      ))}
    </select>
  )
}
