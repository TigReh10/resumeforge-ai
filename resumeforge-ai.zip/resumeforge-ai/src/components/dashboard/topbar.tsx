'use client'

import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAuthStore } from '@/stores/auth-store'
import { api } from '@/lib/api-client'

export function Topbar() {
  const router = useRouter()
  const { user, clear } = useAuthStore()

  async function logout() {
    await api.post('/auth/logout').catch(() => undefined)
    clear()
    router.push('/login')
  }

  return (
    <header className="flex h-16 items-center justify-between border-b px-6">
      <div className="text-sm text-muted-foreground">{user?.email}</div>
      <div className="flex items-center gap-3">
        <Badge variant={user?.planTier === 'FREE' ? 'secondary' : 'success'}>{user?.planTier ?? 'FREE'}</Badge>
        <Button size="sm" variant="ghost" onClick={logout}>Log out</Button>
      </div>
    </header>
  )
}
