'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'
import { useAuthStore } from '@/stores/auth-store'

const NAV = [
  { href: '/dashboard', label: 'Overview' },
  { href: '/dashboard/resumes', label: 'Resumes' },
  { href: '/dashboard/builder', label: 'Resume Builder' },
  { href: '/dashboard/analyze', label: 'ATS Analyzer' },
  { href: '/dashboard/job-match', label: 'Job Match' },
  { href: '/dashboard/cover-letter', label: 'Cover Letters' },
  { href: '/dashboard/linkedin', label: 'LinkedIn' },
  { href: '/dashboard/interview', label: 'Interview Prep' },
  { href: '/dashboard/applications', label: 'Applications' },
  { href: '/dashboard/billing', label: 'Billing' },
  { href: '/dashboard/settings', label: 'Settings' },
]

export function Sidebar() {
  const pathname = usePathname()
  const user = useAuthStore((s) => s.user)
  return (
    <aside className="hidden w-60 shrink-0 border-r bg-card/40 p-4 md:block">
      <Link href="/dashboard" className="mb-6 block px-2 text-lg font-bold">Resume<span className="text-primary">Forge</span></Link>
      <nav className="space-y-1">
        {NAV.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              'block rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-accent',
              pathname === item.href ? 'bg-accent text-foreground' : 'text-muted-foreground',
            )}
          >
            {item.label}
          </Link>
        ))}
        {user?.role === 'ADMIN' && (
          <Link
            href="/admin"
            className={cn('block rounded-md px-3 py-2 text-sm font-medium text-primary hover:bg-accent')}
          >
            Admin Panel
          </Link>
        )}
      </nav>
    </aside>
  )
}
