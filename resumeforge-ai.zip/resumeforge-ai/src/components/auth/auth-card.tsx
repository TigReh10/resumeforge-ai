'use client'

import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

export function AuthCard({
  title,
  description,
  children,
  footer,
}: {
  title: string
  description?: string
  children: React.ReactNode
  footer?: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-muted/30 px-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <Link href="/" className="mb-2 text-lg font-bold">Resume<span className="text-primary">Forge</span> AI</Link>
          <CardTitle className="text-2xl">{title}</CardTitle>
          {description && <CardDescription>{description}</CardDescription>}
        </CardHeader>
        <CardContent>{children}</CardContent>
        {footer && <div className="px-6 pb-6 text-center text-sm text-muted-foreground">{footer}</div>}
      </Card>
    </div>
  )
}

export function GoogleButton() {
  return (
    <Button variant="outline" className="w-full" asChild>
      <a href="/api/auth/google">Continue with Google</a>
    </Button>
  )
}
