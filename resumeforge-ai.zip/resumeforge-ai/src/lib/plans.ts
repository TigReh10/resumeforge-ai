import type { AnalysisType, PlanTier } from '@prisma/client'
import { prisma } from '@/lib/prisma'
import { PlanLimitError } from '@/lib/http'

/** Monthly usage limits per plan. -1 = unlimited. */
export const PLAN_LIMITS: Record<PlanTier, Record<string, number>> = {
  FREE: { resumes: 3, ai: 15 },
  PRO: { resumes: 50, ai: 500 },
  TEAM: { resumes: -1, ai: -1 },
}

export const PLAN_PRICING = {
  PRO: { monthlyEnv: 'STRIPE_PRICE_PRO_MONTHLY', annualEnv: 'STRIPE_PRICE_PRO_ANNUAL' },
  TEAM: { monthlyEnv: 'STRIPE_PRICE_TEAM_MONTHLY', annualEnv: 'STRIPE_PRICE_TEAM_ANNUAL' },
} as const

function currentPeriod(): string {
  const d = new Date()
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}`
}

/**
 * Atomically check + increment AI usage for the period. Throws PlanLimitError
 * when the plan cap is exceeded.
 */
export async function consumeAiUsage(userId: string, plan: PlanTier, feature: AnalysisType) {
  const limit = PLAN_LIMITS[plan].ai ?? 0
  const period = currentPeriod()

  const record = await prisma.usageRecord.upsert({
    where: { userId_feature_period: { userId, feature, period } },
    create: { userId, feature, period, count: 1 },
    update: { count: { increment: 1 } },
  })

  if (limit !== -1) {
    // Sum all AI features for the period to enforce a combined cap.
    const agg = await prisma.usageRecord.aggregate({
      where: { userId, period },
      _sum: { count: true },
    })
    const total = agg._sum.count ?? 0
    if (total > limit) {
      // roll back this increment
      await prisma.usageRecord.update({
        where: { id: record.id },
        data: { count: { decrement: 1 } },
      })
      throw new PlanLimitError(`Monthly AI limit of ${limit} reached on the ${plan} plan`)
    }
  }
}

export async function assertResumeQuota(userId: string, plan: PlanTier) {
  const limit = PLAN_LIMITS[plan].resumes ?? 0
  if (limit === -1) return
  const count = await prisma.resume.count({ where: { userId, isArchived: false } })
  if (count >= limit) {
    throw new PlanLimitError(`Resume limit of ${limit} reached on the ${plan} plan`)
  }
}
