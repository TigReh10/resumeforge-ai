import { headers } from 'next/headers'
import { requireUser, requireAdmin, type AuthUser } from '@/lib/auth/session'
import { rateLimit, RATE_LIMITS } from '@/lib/rate-limit'
import { RateLimitError } from '@/lib/http'

export function clientIp(): string {
  const h = headers()
  return h.get('x-forwarded-for')?.split(',')[0]?.trim() || h.get('x-real-ip') || '0.0.0.0'
}

/** Apply a named rate-limit bucket keyed by an identifier (ip or userId). */
export async function enforceRateLimit(
  bucket: keyof typeof RATE_LIMITS,
  identifier: string,
) {
  const cfg = RATE_LIMITS[bucket]
  const res = await rateLimit(`${bucket}:${identifier}`, cfg.limit, cfg.window)
  if (!res.success) throw new RateLimitError(res.reset)
}

/** Require an authenticated user + apply per-user rate limit for a bucket. */
export async function authed(bucket: keyof typeof RATE_LIMITS = 'default'): Promise<AuthUser> {
  const user = await requireUser()
  await enforceRateLimit(bucket, user.id)
  return user
}

export async function adminOnly(): Promise<AuthUser> {
  const user = await requireAdmin()
  await enforceRateLimit('default', user.id)
  return user
}
