import { prisma } from '@/lib/prisma'
import { complete, completeJson } from '@/lib/ai'
import {
  atsAnalysisPrompt,
  jobMatchPrompt,
  coverLetterPrompt,
  linkedinPrompt,
  interviewPrompt,
  skillGapPrompt,
  careerRoadmapPrompt,
  rewritePrompt,
} from '@/lib/ai/prompts'
import { consumeAiUsage } from '@/lib/plans'
import type { AnalysisType, PlanTier, AiProvider } from '@prisma/client'

function providerEnum(p: 'openai' | 'anthropic'): AiProvider {
  return p === 'openai' ? 'OPENAI' : 'ANTHROPIC'
}

async function getResumeText(resumeId: string, userId: string): Promise<string> {
  const resume = await prisma.resume.findFirstOrThrow({ where: { id: resumeId, userId } })
  return resume.rawText
}

/**
 * Run an AI analysis end-to-end: enforce plan usage, call the model,
 * persist the structured Analysis row, and return it.
 */
export async function runAtsAnalysis(opts: { userId: string; plan: PlanTier; resumeId: string }) {
  await consumeAiUsage(opts.userId, opts.plan, 'ATS_SCORE')
  const text = await getResumeText(opts.resumeId, opts.userId)
  const { data, meta } = await completeJson<{ overallScore: number }>({
    messages: atsAnalysisPrompt(text),
  })
  return prisma.analysis.create({
    data: {
      userId: opts.userId,
      resumeId: opts.resumeId,
      type: 'ATS_SCORE',
      provider: providerEnum(meta.provider),
      model: meta.model,
      inputTokens: meta.inputTokens,
      outputTokens: meta.outputTokens,
      score: data.overallScore,
      result: data as object,
    },
  })
}

export async function runJobMatch(opts: {
  userId: string
  plan: PlanTier
  resumeId: string
  jobPostingId: string
}) {
  await consumeAiUsage(opts.userId, opts.plan, 'JOB_MATCH')
  const [text, job] = await Promise.all([
    getResumeText(opts.resumeId, opts.userId),
    prisma.jobPosting.findFirstOrThrow({ where: { id: opts.jobPostingId, userId: opts.userId } }),
  ])
  const { data, meta } = await completeJson<{ matchPercentage: number }>({
    messages: jobMatchPrompt(text, job.description),
  })
  return prisma.analysis.create({
    data: {
      userId: opts.userId,
      resumeId: opts.resumeId,
      jobPostingId: opts.jobPostingId,
      type: 'JOB_MATCH',
      provider: providerEnum(meta.provider),
      model: meta.model,
      inputTokens: meta.inputTokens,
      outputTokens: meta.outputTokens,
      score: data.matchPercentage,
      result: data as object,
    },
  })
}

export async function generateCoverLetter(opts: {
  userId: string
  plan: PlanTier
  resumeId: string
  jobPostingId: string
  tone: string
}) {
  await consumeAiUsage(opts.userId, opts.plan, 'COVER_LETTER')
  const [text, job] = await Promise.all([
    getResumeText(opts.resumeId, opts.userId),
    prisma.jobPosting.findFirstOrThrow({ where: { id: opts.jobPostingId, userId: opts.userId } }),
  ])
  const meta = await complete({ messages: coverLetterPrompt(text, job.description, opts.tone) })
  return prisma.coverLetter.create({
    data: {
      userId: opts.userId,
      resumeId: opts.resumeId,
      jobPostingId: opts.jobPostingId,
      tone: opts.tone,
      content: meta.text,
    },
  })
}

export async function runLinkedinOptimize(opts: { userId: string; plan: PlanTier; profileText: string }) {
  await consumeAiUsage(opts.userId, opts.plan, 'LINKEDIN')
  const { data, meta } = await completeJson<object>({ messages: linkedinPrompt(opts.profileText) })
  return prisma.analysis.create({
    data: {
      userId: opts.userId,
      type: 'LINKEDIN',
      provider: providerEnum(meta.provider),
      model: meta.model,
      inputTokens: meta.inputTokens,
      outputTokens: meta.outputTokens,
      result: data as object,
    },
  })
}

export async function runInterviewPrep(opts: {
  userId: string
  plan: PlanTier
  resumeId: string
  jobPostingId: string
}) {
  await consumeAiUsage(opts.userId, opts.plan, 'INTERVIEW')
  const [text, job] = await Promise.all([
    getResumeText(opts.resumeId, opts.userId),
    prisma.jobPosting.findFirstOrThrow({ where: { id: opts.jobPostingId, userId: opts.userId } }),
  ])
  const { data, meta } = await completeJson<object>({ messages: interviewPrompt(text, job.description) })
  return prisma.analysis.create({
    data: {
      userId: opts.userId,
      resumeId: opts.resumeId,
      jobPostingId: opts.jobPostingId,
      type: 'INTERVIEW',
      provider: providerEnum(meta.provider),
      model: meta.model,
      inputTokens: meta.inputTokens,
      outputTokens: meta.outputTokens,
      result: data as object,
    },
  })
}

export async function runSkillGap(opts: {
  userId: string
  plan: PlanTier
  resumeId: string
  jobPostingId: string
}) {
  await consumeAiUsage(opts.userId, opts.plan, 'SKILL_GAP')
  const [text, job] = await Promise.all([
    getResumeText(opts.resumeId, opts.userId),
    prisma.jobPosting.findFirstOrThrow({ where: { id: opts.jobPostingId, userId: opts.userId } }),
  ])
  const { data, meta } = await completeJson<object>({ messages: skillGapPrompt(text, job.description) })
  return prisma.analysis.create({
    data: {
      userId: opts.userId,
      resumeId: opts.resumeId,
      jobPostingId: opts.jobPostingId,
      type: 'SKILL_GAP',
      provider: providerEnum(meta.provider),
      model: meta.model,
      inputTokens: meta.inputTokens,
      outputTokens: meta.outputTokens,
      result: data as object,
    },
  })
}

export async function runCareerRoadmap(opts: {
  userId: string
  plan: PlanTier
  resumeId: string
  goal: string
}) {
  await consumeAiUsage(opts.userId, opts.plan, 'CAREER_ROADMAP')
  const text = await getResumeText(opts.resumeId, opts.userId)
  const { data, meta } = await completeJson<object>({ messages: careerRoadmapPrompt(text, opts.goal) })
  return prisma.analysis.create({
    data: {
      userId: opts.userId,
      resumeId: opts.resumeId,
      type: 'CAREER_ROADMAP',
      provider: providerEnum(meta.provider),
      model: meta.model,
      inputTokens: meta.inputTokens,
      outputTokens: meta.outputTokens,
      result: data as object,
    },
  })
}

export async function rewriteResume(opts: {
  userId: string
  plan: PlanTier
  resumeId: string
  jobPostingId?: string
}) {
  await consumeAiUsage(opts.userId, opts.plan, 'REWRITE')
  const text = await getResumeText(opts.resumeId, opts.userId)
  let jobDescription: string | undefined
  if (opts.jobPostingId) {
    const job = await prisma.jobPosting.findFirstOrThrow({
      where: { id: opts.jobPostingId, userId: opts.userId },
    })
    jobDescription = job.description
  }
  const meta = await complete({ messages: rewritePrompt(text, jobDescription) })

  // Save as a new resume version
  const last = await prisma.resumeVersion.findFirst({
    where: { resumeId: opts.resumeId },
    orderBy: { version: 'desc' },
  })
  const version = (last?.version ?? 0) + 1
  return prisma.resumeVersion.create({
    data: {
      resumeId: opts.resumeId,
      version,
      label: opts.jobPostingId ? 'AI rewrite (tailored)' : 'AI rewrite',
      content: { text: meta.text } as object,
    },
  })
}

/** Dispatch table used by the queue worker. */
export async function runByType(data: {
  type: AnalysisType
  userId: string
  plan: PlanTier
  payload: Record<string, any>
}) {
  const { type, userId, plan, payload } = data
  switch (type) {
    case 'ATS_SCORE':
      return runAtsAnalysis({ userId, plan, resumeId: payload.resumeId })
    case 'JOB_MATCH':
      return runJobMatch({ userId, plan, resumeId: payload.resumeId, jobPostingId: payload.jobPostingId })
    case 'COVER_LETTER':
      return generateCoverLetter({
        userId,
        plan,
        resumeId: payload.resumeId,
        jobPostingId: payload.jobPostingId,
        tone: payload.tone ?? 'professional',
      })
    case 'LINKEDIN':
      return runLinkedinOptimize({ userId, plan, profileText: payload.profileText })
    case 'INTERVIEW':
      return runInterviewPrep({ userId, plan, resumeId: payload.resumeId, jobPostingId: payload.jobPostingId })
    case 'SKILL_GAP':
      return runSkillGap({ userId, plan, resumeId: payload.resumeId, jobPostingId: payload.jobPostingId })
    case 'CAREER_ROADMAP':
      return runCareerRoadmap({ userId, plan, resumeId: payload.resumeId, goal: payload.goal })
    case 'REWRITE':
      return rewriteResume({ userId, plan, resumeId: payload.resumeId, jobPostingId: payload.jobPostingId })
    default:
      throw new Error(`Unknown analysis type: ${type}`)
  }
}
