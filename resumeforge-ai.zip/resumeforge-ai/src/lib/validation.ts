import { z } from 'zod'

export const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(10).max(128),
  name: z.string().min(1).max(120).optional(),
})

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  totp: z.string().optional(),
})

export const requestResetSchema = z.object({ email: z.string().email() })

export const performResetSchema = z.object({
  token: z.string().min(10),
  password: z.string().min(10).max(128),
})

export const verifyEmailSchema = z.object({ token: z.string().min(10) })

export const enable2faSchema = z.object({ totp: z.string().min(6).max(8) })

export const jobPostingSchema = z.object({
  title: z.string().min(1).max(200),
  company: z.string().max(200).optional(),
  location: z.string().max(200).optional(),
  url: z.string().url().optional(),
  description: z.string().min(20).max(20000),
})

export const analyzeSchema = z.object({ resumeId: z.string().cuid() })

export const jobMatchSchema = z.object({
  resumeId: z.string().cuid(),
  jobPostingId: z.string().cuid(),
})

export const coverLetterSchema = z.object({
  resumeId: z.string().cuid(),
  jobPostingId: z.string().cuid(),
  tone: z.enum(['professional', 'enthusiastic', 'formal', 'conversational', 'concise']).default('professional'),
})

export const linkedinSchema = z.object({ profileText: z.string().min(20).max(15000) })

export const interviewSchema = jobMatchSchema
export const skillGapSchema = jobMatchSchema

export const roadmapSchema = z.object({
  resumeId: z.string().cuid(),
  goal: z.string().min(3).max(300),
})

export const rewriteSchema = z.object({
  resumeId: z.string().cuid(),
  jobPostingId: z.string().cuid().optional(),
})

export const applicationSchema = z.object({
  resumeId: z.string().cuid().optional(),
  jobPostingId: z.string().cuid().optional(),
  stage: z.enum(['SAVED', 'APPLIED', 'INTERVIEWING', 'OFFER', 'REJECTED']).default('SAVED'),
  notes: z.string().max(5000).optional(),
})

export const checkoutSchema = z.object({
  plan: z.enum(['PRO', 'TEAM']),
  interval: z.enum(['month', 'year']),
})
