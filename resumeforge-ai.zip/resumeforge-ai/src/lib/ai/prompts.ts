/**
 * Prompt builders for every ResumeForge AI feature. Kept pure (string in/out)
 * so they are unit-testable and provider-agnostic.
 */
import type { ChatMessage } from './types'

const SYSTEM_BASE =
  'You are ResumeForge AI, an expert career coach, technical recruiter, and ATS specialist. ' +
  'You give precise, actionable, honest feedback. When asked for JSON, you output only valid JSON ' +
  'with no markdown fences and no commentary.'

export function atsAnalysisPrompt(resumeText: string): ChatMessage[] {
  return [
    { role: 'system', content: SYSTEM_BASE },
    {
      role: 'user',
      content: `Analyze the following resume for ATS compatibility and quality. Return JSON matching exactly this TypeScript type:
{
  "overallScore": number,            // 0-100
  "sectionScores": {
    "formatting": number, "readability": number, "keywords": number,
    "experienceQuality": number, "actionVerbs": number, "industryAlignment": number,
    "grammar": number
  },
  "missingSkills": string[],
  "grammarIssues": { "text": string, "suggestion": string }[],
  "recommendations": { "priority": "high"|"medium"|"low", "title": string, "detail": string }[],
  "summary": string
}
Resume:
"""
${resumeText}
"""`,
    },
  ]
}

export function jobMatchPrompt(resumeText: string, jobDescription: string): ChatMessage[] {
  return [
    { role: 'system', content: SYSTEM_BASE },
    {
      role: 'user',
      content: `Compare the resume to the job description. Return JSON:
{
  "matchPercentage": number,        // 0-100
  "matchedKeywords": string[],
  "missingKeywords": string[],
  "missingSkills": string[],
  "suggestedEdits": { "section": string, "suggestion": string }[],
  "recruiterView": string,          // 2-3 sentence simulated recruiter first impression
  "verdict": "strong"|"moderate"|"weak"
}
RESUME:
"""${resumeText}"""
JOB DESCRIPTION:
"""${jobDescription}"""`,
    },
  ]
}

export function coverLetterPrompt(
  resumeText: string,
  jobDescription: string,
  tone: string,
): ChatMessage[] {
  return [
    { role: 'system', content: SYSTEM_BASE },
    {
      role: 'user',
      content: `Write a tailored, ${tone} cover letter (max ~350 words) for this candidate and role. ` +
        `Use concrete achievements from the resume. Do not invent facts. Output plain text only.\n` +
        `RESUME:\n"""${resumeText}"""\nJOB:\n"""${jobDescription}"""`,
    },
  ]
}

export function linkedinPrompt(profileText: string): ChatMessage[] {
  return [
    { role: 'system', content: SYSTEM_BASE },
    {
      role: 'user',
      content: `Optimize this LinkedIn profile. Return JSON:
{
  "analysis": { "headline": string, "about": string, "experience": string, "skills": string },
  "improvedHeadline": string,
  "improvedAbout": string,
  "recruiterTips": string[]
}
PROFILE:
"""${profileText}"""`,
    },
  ]
}

export function interviewPrompt(resumeText: string, jobDescription: string): ChatMessage[] {
  return [
    { role: 'system', content: SYSTEM_BASE },
    {
      role: 'user',
      content: `Generate interview prep. Return JSON:
{
  "behavioral": { "question": string, "suggestedAnswer": string }[],
  "technical": { "question": string, "suggestedAnswer": string }[],
  "followUps": string[]
}
Base questions on the resume and job posting.
RESUME:
"""${resumeText}"""
JOB:
"""${jobDescription}"""`,
    },
  ]
}

export function skillGapPrompt(resumeText: string, jobDescription: string): ChatMessage[] {
  return [
    { role: 'system', content: SYSTEM_BASE },
    {
      role: 'user',
      content: `Produce a skill-gap analysis. Return JSON:
{
  "haveSkills": string[],
  "gapSkills": { "skill": string, "importance": "critical"|"nice-to-have", "howToLearn": string }[],
  "readinessScore": number
}
RESUME:
"""${resumeText}"""
TARGET ROLE:
"""${jobDescription}"""`,
    },
  ]
}

export function careerRoadmapPrompt(resumeText: string, goal: string): ChatMessage[] {
  return [
    { role: 'system', content: SYSTEM_BASE },
    {
      role: 'user',
      content: `Create a career roadmap toward the stated goal. Return JSON:
{
  "currentLevel": string,
  "targetLevel": string,
  "milestones": { "timeframe": string, "focus": string, "actions": string[] }[],
  "recommendedCertifications": string[]
}
RESUME:
"""${resumeText}"""
GOAL: ${goal}`,
    },
  ]
}

export function rewritePrompt(resumeText: string, jobDescription?: string): ChatMessage[] {
  return [
    { role: 'system', content: SYSTEM_BASE },
    {
      role: 'user',
      content: `Rewrite/optimize this resume${jobDescription ? ' for the target job' : ''}. ` +
        `Keep all facts truthful, strengthen action verbs and quantification, improve ATS keyword coverage. ` +
        `Output plain text resume only.\nRESUME:\n"""${resumeText}"""` +
        (jobDescription ? `\nJOB:\n"""${jobDescription}"""` : ''),
    },
  ]
}
