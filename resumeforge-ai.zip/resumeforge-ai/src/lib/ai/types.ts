export type ChatRole = 'system' | 'user' | 'assistant'

export type ChatMessage = { role: ChatRole; content: string }

export type CompletionOptions = {
  messages: ChatMessage[]
  temperature?: number
  maxTokens?: number
  json?: boolean // force JSON output
}

export type CompletionResult = {
  text: string
  provider: 'openai' | 'anthropic'
  model: string
  inputTokens: number
  outputTokens: number
}

export interface AiProviderClient {
  readonly name: 'openai' | 'anthropic'
  readonly available: boolean
  complete(opts: CompletionOptions): Promise<CompletionResult>
  stream(opts: CompletionOptions): AsyncGenerator<string, CompletionResult, unknown>
}
