import Anthropic from '@anthropic-ai/sdk'
import { env } from '@/env'
import type { AiProviderClient, ChatMessage, CompletionOptions, CompletionResult } from './types'

function splitSystem(messages: ChatMessage[]) {
  const system = messages
    .filter((m) => m.role === 'system')
    .map((m) => m.content)
    .join('\n\n')
  const rest = messages
    .filter((m) => m.role !== 'system')
    .map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }))
  return { system, rest }
}

export class AnthropicClient implements AiProviderClient {
  readonly name = 'anthropic' as const
  private client: Anthropic | null
  constructor() {
    this.client = env.ANTHROPIC_API_KEY ? new Anthropic({ apiKey: env.ANTHROPIC_API_KEY }) : null
  }
  get available() {
    return this.client !== null
  }

  async complete(opts: CompletionOptions): Promise<CompletionResult> {
    if (!this.client) throw new Error('Anthropic not configured')
    const { system, rest } = splitSystem(opts.messages)
    const res = await this.client.messages.create({
      model: env.ANTHROPIC_MODEL,
      max_tokens: opts.maxTokens ?? 2048,
      temperature: opts.temperature ?? 0.4,
      system: opts.json ? `${system}\n\nRespond with valid JSON only.` : system,
      messages: rest,
    })
    const text = res.content.map((c) => (c.type === 'text' ? c.text : '')).join('')
    return {
      text,
      provider: 'anthropic',
      model: env.ANTHROPIC_MODEL,
      inputTokens: res.usage.input_tokens,
      outputTokens: res.usage.output_tokens,
    }
  }

  async *stream(opts: CompletionOptions): AsyncGenerator<string, CompletionResult, unknown> {
    if (!this.client) throw new Error('Anthropic not configured')
    const { system, rest } = splitSystem(opts.messages)
    const stream = this.client.messages.stream({
      model: env.ANTHROPIC_MODEL,
      max_tokens: opts.maxTokens ?? 2048,
      temperature: opts.temperature ?? 0.4,
      system,
      messages: rest,
    })
    let text = ''
    for await (const event of stream) {
      if (event.type === 'content_block_delta' && event.delta.type === 'text_delta') {
        text += event.delta.text
        yield event.delta.text
      }
    }
    const final = await stream.finalMessage()
    return {
      text,
      provider: 'anthropic',
      model: env.ANTHROPIC_MODEL,
      inputTokens: final.usage.input_tokens,
      outputTokens: final.usage.output_tokens,
    }
  }
}
