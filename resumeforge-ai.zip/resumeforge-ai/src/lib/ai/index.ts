import { OpenAiClient } from './openai'
import { AnthropicClient } from './anthropic'
import { env } from '@/env'
import { logger } from '@/lib/logger'
import type { AiProviderClient, CompletionOptions, CompletionResult } from './types'

const openai = new OpenAiClient()
const anthropic = new AnthropicClient()

/** Ordered provider chain: primary first, then fallback. Filters unconfigured. */
function providerChain(): AiProviderClient[] {
  const primary = env.AI_PRIMARY_PROVIDER === 'anthropic' ? anthropic : openai
  const secondary = env.AI_PRIMARY_PROVIDER === 'anthropic' ? openai : anthropic
  return [primary, secondary].filter((p) => p.available)
}

async function withRetry<T>(fn: () => Promise<T>, retries = 2, baseDelay = 400): Promise<T> {
  let lastErr: unknown
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn()
    } catch (err) {
      lastErr = err
      if (attempt < retries) {
        await new Promise((r) => setTimeout(r, baseDelay * 2 ** attempt))
      }
    }
  }
  throw lastErr
}

/**
 * Provider-agnostic completion with automatic fallback. Tries the primary
 * provider (with retries/backoff); on hard failure, fails over to the next.
 */
export async function complete(opts: CompletionOptions): Promise<CompletionResult> {
  const chain = providerChain()
  if (chain.length === 0) throw new Error('No AI provider configured')
  let lastErr: unknown
  for (const provider of chain) {
    try {
      return await withRetry(() => provider.complete(opts))
    } catch (err) {
      lastErr = err
      logger.warn({ err, provider: provider.name }, 'AI provider failed, falling back')
    }
  }
  throw lastErr ?? new Error('All AI providers failed')
}

/** Parse a JSON completion safely, tolerating code fences. */
export async function completeJson<T>(opts: CompletionOptions): Promise<{ data: T; meta: CompletionResult }> {
  const meta = await complete({ ...opts, json: true })
  const cleaned = meta.text
    .trim()
    .replace(/^```(?:json)?/i, '')
    .replace(/```$/, '')
    .trim()
  const data = JSON.parse(cleaned) as T
  return { data, meta }
}

/** Streaming completion with fallback only on connection (pre-first-token) failure. */
export async function* streamComplete(
  opts: CompletionOptions,
): AsyncGenerator<string, CompletionResult, unknown> {
  const chain = providerChain()
  if (chain.length === 0) throw new Error('No AI provider configured')
  let lastErr: unknown
  for (const provider of chain) {
    try {
      const gen = provider.stream(opts)
      let result = await gen.next()
      while (!result.done) {
        yield result.value
        result = await gen.next()
      }
      return result.value
    } catch (err) {
      lastErr = err
      logger.warn({ err, provider: provider.name }, 'AI stream failed, trying fallback')
    }
  }
  throw lastErr ?? new Error('All AI providers failed')
}

export function aiHealth() {
  return { openai: openai.available, anthropic: anthropic.available, primary: env.AI_PRIMARY_PROVIDER }
}
