import OpenAI from 'openai'
import { env } from '@/env'
import type { AiProviderClient, CompletionOptions, CompletionResult } from './types'

export class OpenAiClient implements AiProviderClient {
  readonly name = 'openai' as const
  private client: OpenAI | null
  constructor() {
    this.client = env.OPENAI_API_KEY ? new OpenAI({ apiKey: env.OPENAI_API_KEY }) : null
  }
  get available() {
    return this.client !== null
  }

  async complete(opts: CompletionOptions): Promise<CompletionResult> {
    if (!this.client) throw new Error('OpenAI not configured')
    const res = await this.client.chat.completions.create({
      model: env.OPENAI_MODEL,
      temperature: opts.temperature ?? 0.4,
      max_tokens: opts.maxTokens ?? 2048,
      response_format: opts.json ? { type: 'json_object' } : undefined,
      messages: opts.messages,
    })
    return {
      text: res.choices[0]?.message?.content ?? '',
      provider: 'openai',
      model: env.OPENAI_MODEL,
      inputTokens: res.usage?.prompt_tokens ?? 0,
      outputTokens: res.usage?.completion_tokens ?? 0,
    }
  }

  async *stream(opts: CompletionOptions): AsyncGenerator<string, CompletionResult, unknown> {
    if (!this.client) throw new Error('OpenAI not configured')
    const stream = await this.client.chat.completions.create({
      model: env.OPENAI_MODEL,
      temperature: opts.temperature ?? 0.4,
      max_tokens: opts.maxTokens ?? 2048,
      messages: opts.messages,
      stream: true,
      stream_options: { include_usage: true },
    })
    let text = ''
    let inputTokens = 0
    let outputTokens = 0
    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta?.content ?? ''
      if (delta) {
        text += delta
        yield delta
      }
      if (chunk.usage) {
        inputTokens = chunk.usage.prompt_tokens
        outputTokens = chunk.usage.completion_tokens
      }
    }
    return { text, provider: 'openai', model: env.OPENAI_MODEL, inputTokens, outputTokens }
  }
}
