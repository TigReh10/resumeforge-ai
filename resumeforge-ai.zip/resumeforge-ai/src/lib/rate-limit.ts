import { redis } from '@/lib/redis'

export type RateLimitResult = {
  success: boolean
  limit: number
  remaining: number
  reset: number // epoch seconds
}

/**
 * Fixed-window rate limiter backed by Redis (atomic INCR + EXPIRE via pipeline).
 * Suitable for per-IP and per-user throttling. For 100k+ users this runs on a
 * shared Redis cluster; keys auto-expire so memory stays bounded.
 */
export async function rateLimit(
  key: string,
  limit: number,
  windowSeconds: number,
): Promise<RateLimitResult> {
  const bucket = Math.floor(Date.now() / 1000 / windowSeconds)
  const redisKey = `rl:${key}:${bucket}`
  const pipeline = redis.pipeline()
  pipeline.incr(redisKey)
  pipeline.expire(redisKey, windowSeconds)
  const results = await pipeline.exec()
  const count = (results?.[0]?.[1] as number) ?? 0
  const reset = (bucket + 1) * windowSeconds
  return {
    success: count <= limit,
    limit,
    remaining: Math.max(0, limit - count),
    reset,
  }
}

export const RATE_LIMITS = {
  auth: { limit: 10, window: 60 }, // 10 attempts / minute
  ai: { limit: 30, window: 60 }, // 30 AI calls / minute
  upload: { limit: 20, window: 300 },
  default: { limit: 120, window: 60 },
} as const
