import { Queue, QueueEvents, type JobsOptions } from 'bullmq'
import { redis } from '@/lib/redis'
import type { AnalysisType } from '@prisma/client'

export const AI_QUEUE = 'ai-processing'

export type AiJobData = {
  aiJobId: string
  userId: string
  plan: 'FREE' | 'PRO' | 'TEAM'
  type: AnalysisType
  payload: Record<string, unknown>
}

const defaultJobOptions: JobsOptions = {
  attempts: 3,
  backoff: { type: 'exponential', delay: 2000 },
  removeOnComplete: { age: 3600, count: 1000 },
  removeOnFail: { age: 24 * 3600 },
}

let queue: Queue<AiJobData> | null = null

export function getAiQueue(): Queue<AiJobData> {
  if (!queue) {
    queue = new Queue<AiJobData>(AI_QUEUE, { connection: redis, defaultJobOptions })
  }
  return queue
}

export function getAiQueueEvents(): QueueEvents {
  return new QueueEvents(AI_QUEUE, { connection: redis })
}

export async function enqueueAiJob(data: AiJobData) {
  return getAiQueue().add(data.type, data, { jobId: data.aiJobId })
}
