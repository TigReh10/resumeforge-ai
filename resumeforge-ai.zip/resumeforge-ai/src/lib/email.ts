import nodemailer from 'nodemailer'
import { env } from '@/env'
import { logger } from '@/lib/logger'

const transporter =
  env.SMTP_HOST && env.SMTP_USER
    ? nodemailer.createTransport({
        host: env.SMTP_HOST,
        port: env.SMTP_PORT,
        secure: env.SMTP_PORT === 465,
        auth: { user: env.SMTP_USER, pass: env.SMTP_PASSWORD },
      })
    : null

export async function sendEmail(to: string, subject: string, html: string) {
  if (!transporter) {
    // In dev/test without SMTP configured, log instead of failing.
    logger.info({ to, subject }, '[email:dev] would send email')
    return
  }
  await transporter.sendMail({ from: env.EMAIL_FROM, to, subject, html })
}

export function verifyEmailTemplate(link: string) {
  return `<h2>Verify your email</h2><p>Welcome to ResumeForge AI. Confirm your address:</p><p><a href="${link}">Verify email</a></p><p>This link expires in 24 hours.</p>`
}

export function resetPasswordTemplate(link: string) {
  return `<h2>Reset your password</h2><p>Click below to choose a new password:</p><p><a href="${link}">Reset password</a></p><p>This link expires in 1 hour. If you didn't request this, ignore this email.</p>`
}
