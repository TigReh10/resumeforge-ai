import mammoth from 'mammoth'
import crypto from 'node:crypto'
import type { ResumeFileType } from '@prisma/client'

const MAX_BYTES = 8 * 1024 * 1024 // 8MB
const SIGNATURES: Record<string, number[][]> = {
  pdf: [[0x25, 0x50, 0x44, 0x46]], // %PDF
  docx: [[0x50, 0x4b, 0x03, 0x04]], // PK.. (zip)
}

export class FileValidationError extends Error {}

function matchesSignature(buf: Buffer, sigs: number[][]): boolean {
  return sigs.some((sig) => sig.every((byte, i) => buf[i] === byte))
}

/**
 * Validate an uploaded resume by extension AND magic bytes (defense against
 * content-type spoofing) and enforce a size cap.
 */
export function validateUpload(filename: string, buf: Buffer): ResumeFileType {
  if (buf.length === 0) throw new FileValidationError('Empty file')
  if (buf.length > MAX_BYTES) throw new FileValidationError('File exceeds 8MB limit')
  const ext = filename.toLowerCase().split('.').pop()
  switch (ext) {
    case 'pdf':
      if (!matchesSignature(buf, SIGNATURES.pdf)) throw new FileValidationError('Invalid PDF file')
      return 'PDF'
    case 'docx':
      if (!matchesSignature(buf, SIGNATURES.docx)) throw new FileValidationError('Invalid DOCX file')
      return 'DOCX'
    case 'txt':
      return 'TXT'
    default:
      throw new FileValidationError('Unsupported file type. Use PDF, DOCX, or TXT.')
  }
}

export async function extractText(buf: Buffer, type: ResumeFileType): Promise<string> {
  if (type === 'TXT') return buf.toString('utf8')
  if (type === 'DOCX') {
    const { value } = await mammoth.extractRawText({ buffer: buf })
    return value
  }
  // PDF — dynamic import avoids pulling pdf-parse test harness into the bundle
  const pdfParse = (await import('pdf-parse')).default
  const data = await pdfParse(buf)
  return data.text
}

export function checksum(buf: Buffer): string {
  return crypto.createHash('sha256').update(buf).digest('hex')
}

/** Lightweight heuristic section parser (no AI) for quick structured preview. */
export function naiveStructure(text: string) {
  const emailMatch = text.match(/[\w.+-]+@[\w-]+\.[\w.-]+/)
  const phoneMatch = text.match(/(\+?\d[\d\s().-]{7,}\d)/)
  const sections: Record<string, string> = {}
  const headers = ['experience', 'education', 'skills', 'projects', 'summary', 'certifications']
  const lower = text.toLowerCase()
  for (const h of headers) {
    const idx = lower.indexOf(h)
    if (idx >= 0) sections[h] = text.slice(idx, idx + 1200)
  }
  return {
    email: emailMatch?.[0] ?? null,
    phone: phoneMatch?.[0] ?? null,
    sections,
    wordCount: text.split(/\s+/).filter(Boolean).length,
  }
}
