import Stripe from 'stripe'
import { env } from '@/env'
import { prisma } from '@/lib/prisma'
import type { PlanTier, BillingInterval } from '@prisma/client'

export const stripe = env.STRIPE_SECRET_KEY
  ? new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: '2024-06-20' })
  : (null as unknown as Stripe)

export function priceIdFor(plan: 'PRO' | 'TEAM', interval: 'month' | 'year'): string {
  const map = {
    PRO: { month: env.STRIPE_PRICE_PRO_MONTHLY, year: env.STRIPE_PRICE_PRO_ANNUAL },
    TEAM: { month: env.STRIPE_PRICE_TEAM_MONTHLY, year: env.STRIPE_PRICE_TEAM_ANNUAL },
  }
  return map[plan][interval]
}

export function planFromPriceId(priceId: string | null | undefined): PlanTier {
  if (!priceId) return 'FREE'
  if (priceId === env.STRIPE_PRICE_TEAM_MONTHLY || priceId === env.STRIPE_PRICE_TEAM_ANNUAL) return 'TEAM'
  if (priceId === env.STRIPE_PRICE_PRO_MONTHLY || priceId === env.STRIPE_PRICE_PRO_ANNUAL) return 'PRO'
  return 'FREE'
}

export function intervalFromPriceId(priceId: string | null | undefined): BillingInterval | null {
  if (!priceId) return null
  if (priceId === env.STRIPE_PRICE_PRO_ANNUAL || priceId === env.STRIPE_PRICE_TEAM_ANNUAL) return 'YEAR'
  return 'MONTH'
}

/** Ensure the user has a Stripe customer; persist the id on first use. */
export async function ensureCustomer(userId: string, email: string): Promise<string> {
  const existing = await prisma.subscription.findUnique({ where: { userId } })
  if (existing?.stripeCustomerId) return existing.stripeCustomerId
  const customer = await stripe.customers.create({ email, metadata: { userId } })
  await prisma.subscription.upsert({
    where: { userId },
    create: { userId, stripeCustomerId: customer.id, planTier: 'FREE', status: 'ACTIVE' },
    update: { stripeCustomerId: customer.id },
  })
  return customer.id
}
