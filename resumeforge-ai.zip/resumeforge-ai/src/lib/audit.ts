import { prisma } from '@/lib/prisma'
import { logger } from '@/lib/logger'

export async function audit(params: {
  userId?: string | null
  action: string
  entity?: string
  entityId?: string
  ip?: string
  userAgent?: string
  metadata?: Record<string, unknown>
}) {
  try {
    await prisma.auditLog.create({
      data: {
        userId: params.userId ?? null,
        action: params.action,
        entity: params.entity,
        entityId: params.entityId,
        ip: params.ip,
        userAgent: params.userAgent,
        metadata: params.metadata as object | undefined,
      },
    })
  } catch (err) {
    logger.error({ err, action: params.action }, 'Failed to write audit log')
  }
}
