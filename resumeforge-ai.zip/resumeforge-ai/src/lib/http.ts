import { NextResponse } from 'next/server'
import { ZodError } from 'zod'
import { logger } from '@/lib/logger'
import { UnauthorizedError, ForbiddenError } from '@/lib/auth/session'

export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
  ) {
    super(message)
  }
}

export class RateLimitError extends HttpError {
  constructor(public reset: number) {
    super(429, 'Too many requests', 'rate_limited')
  }
}

export class PlanLimitError extends HttpError {
  constructor(message = 'Usage limit reached for your plan') {
    super(402, message, 'plan_limit')
  }
}

export function ok<T>(data: T, init?: ResponseInit) {
  return NextResponse.json({ data }, { status: 200, ...init })
}

export function created<T>(data: T) {
  return NextResponse.json({ data }, { status: 201 })
}

/** Convert any thrown error into a safe JSON response (never leak internals). */
export function handleError(err: unknown): NextResponse {
  if (err instanceof ZodError) {
    return NextResponse.json(
      { error: { code: 'validation_error', message: 'Invalid input', issues: err.flatten() } },
      { status: 422 },
    )
  }
  if (err instanceof UnauthorizedError) {
    return NextResponse.json({ error: { code: 'unauthorized', message: err.message } }, { status: 401 })
  }
  if (err instanceof ForbiddenError) {
    return NextResponse.json({ error: { code: 'forbidden', message: err.message } }, { status: 403 })
  }
  if (err instanceof RateLimitError) {
    return NextResponse.json(
      { error: { code: err.code, message: err.message } },
      { status: 429, headers: { 'Retry-After': String(Math.max(0, err.reset - Math.floor(Date.now() / 1000))) } },
    )
  }
  if (err instanceof HttpError) {
    return NextResponse.json({ error: { code: err.code ?? 'error', message: err.message } }, { status: err.status })
  }
  logger.error({ err }, 'Unhandled API error')
  return NextResponse.json({ error: { code: 'internal_error', message: 'Something went wrong' } }, { status: 500 })
}
