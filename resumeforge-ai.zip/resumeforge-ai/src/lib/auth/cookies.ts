import { cookies } from 'next/headers'
import { env } from '@/env'

export const ACCESS_COOKIE = 'rf_access'
export const REFRESH_COOKIE = 'rf_refresh'

const secure = env.NODE_ENV === 'production'

export function setAuthCookies(accessToken: string, refreshToken: string) {
  const store = cookies()
  store.set(ACCESS_COOKIE, accessToken, {
    httpOnly: true,
    secure,
    sameSite: 'lax',
    path: '/',
    maxAge: env.ACCESS_TOKEN_TTL,
  })
  store.set(REFRESH_COOKIE, refreshToken, {
    httpOnly: true,
    secure,
    sameSite: 'lax',
    path: '/',
    maxAge: env.REFRESH_TOKEN_TTL,
  })
}

export function clearAuthCookies() {
  const store = cookies()
  store.delete(ACCESS_COOKIE)
  store.delete(REFRESH_COOKIE)
}
