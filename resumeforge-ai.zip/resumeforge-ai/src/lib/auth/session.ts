import { cookies, headers } from 'next/headers'
import { prisma } from '@/lib/prisma'
import { sha256 } from '@/lib/crypto'
import {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
} from './jwt'
import { ACCESS_COOKIE, REFRESH_COOKIE } from './cookies'
import { env } from '@/env'
import type { User } from '@prisma/client'

export type AuthUser = {
  id: string
  email: string
  role: 'USER' | 'ADMIN'
  plan: 'FREE' | 'PRO' | 'TEAM'
}

/** Issue a new access+refresh pair and persist the refresh session. */
export async function createSession(user: User, meta: { ip?: string; userAgent?: string }) {
  const accessToken = await signAccessToken({
    sub: user.id,
    email: user.email,
    role: user.role,
    plan: user.planTier,
  })
  const sessionId = crypto.randomUUID()
  const refreshToken = await signRefreshToken({ sub: user.id, sid: sessionId })

  await prisma.session.create({
    data: {
      id: sessionId,
      userId: user.id,
      refreshHash: sha256(refreshToken),
      ip: meta.ip,
      userAgent: meta.userAgent,
      expiresAt: new Date(Date.now() + env.REFRESH_TOKEN_TTL * 1000),
    },
  })

  return { accessToken, refreshToken }
}

/** Rotate a refresh token: validates, revokes the old session, issues a new pair. */
export async function rotateRefreshToken(refreshToken: string, meta: { ip?: string; userAgent?: string }) {
  const claims = await verifyRefreshToken(refreshToken)
  const session = await prisma.session.findUnique({ where: { id: claims.sid } })
  if (!session || session.revokedAt || session.expiresAt < new Date()) {
    throw new Error('Invalid session')
  }
  if (session.refreshHash !== sha256(refreshToken)) {
    // Possible token reuse — revoke all sessions for this user (breach response).
    await prisma.session.updateMany({
      where: { userId: session.userId, revokedAt: null },
      data: { revokedAt: new Date() },
    })
    throw new Error('Refresh token reuse detected')
  }
  const user = await prisma.user.findUniqueOrThrow({ where: { id: session.userId } })
  await prisma.session.update({ where: { id: session.id }, data: { revokedAt: new Date() } })
  return createSession(user, meta)
}

export async function revokeSession(refreshToken: string) {
  try {
    const claims = await verifyRefreshToken(refreshToken)
    await prisma.session.updateMany({
      where: { id: claims.sid, revokedAt: null },
      data: { revokedAt: new Date() },
    })
  } catch {
    /* ignore */
  }
}

/** Resolve the current user from the access cookie (server components / route handlers). */
export async function getCurrentUser(): Promise<AuthUser | null> {
  const token = cookies().get(ACCESS_COOKIE)?.value
  if (!token) return null
  try {
    const claims = await verifyAccessToken(token)
    return { id: claims.sub, email: claims.email, role: claims.role, plan: claims.plan }
  } catch {
    return null
  }
}

export async function requireUser(): Promise<AuthUser> {
  const user = await getCurrentUser()
  if (!user) throw new UnauthorizedError()
  return user
}

export async function requireAdmin(): Promise<AuthUser> {
  const user = await requireUser()
  if (user.role !== 'ADMIN') throw new ForbiddenError()
  return user
}

export function requestMeta() {
  const h = headers()
  return {
    ip: h.get('x-forwarded-for')?.split(',')[0]?.trim() || h.get('x-real-ip') || undefined,
    userAgent: h.get('user-agent') || undefined,
  }
}

export class UnauthorizedError extends Error {
  status = 401
  constructor() {
    super('Unauthorized')
  }
}
export class ForbiddenError extends Error {
  status = 403
  constructor() {
    super('Forbidden')
  }
}

// re-export cookie names for convenience
export { ACCESS_COOKIE, REFRESH_COOKIE }
