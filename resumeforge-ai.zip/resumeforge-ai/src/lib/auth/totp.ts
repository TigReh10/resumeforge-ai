import * as OTPAuth from 'otpauth'
import crypto from 'node:crypto'
import { encrypt, decrypt } from '@/lib/crypto'

const ISSUER = 'ResumeForge AI'

export function generateTotpSecret(): string {
  return new OTPAuth.Secret({ size: 20 }).base32
}

export function buildTotp(secret: string, label: string): OTPAuth.TOTP {
  return new OTPAuth.TOTP({
    issuer: ISSUER,
    label,
    algorithm: 'SHA1',
    digits: 6,
    period: 30,
    secret: OTPAuth.Secret.fromBase32(secret),
  })
}

export function totpAuthUri(secret: string, label: string): string {
  return buildTotp(secret, label).toString()
}

export function verifyTotp(secret: string, token: string): boolean {
  const totp = buildTotp(secret, 'verify')
  // window: 1 = allow +/- one 30s step for clock drift
  return totp.validate({ token: token.replace(/\s/g, ''), window: 1 }) !== null
}

export function encryptSecret(secret: string): string {
  return encrypt(secret)
}

export function decryptSecret(payload: string): string {
  return decrypt(payload)
}

/** Generate hashed one-time recovery codes; returns plaintext (show once) + hashes (store). */
export function generateRecoveryCodes(count = 10): { plaintext: string[]; hashes: string[] } {
  const plaintext: string[] = []
  const hashes: string[] = []
  for (let i = 0; i < count; i++) {
    const code = crypto.randomBytes(5).toString('hex') // 10 chars
    plaintext.push(code)
    hashes.push(crypto.createHash('sha256').update(code).digest('hex'))
  }
  return { plaintext, hashes }
}

export function hashRecoveryCode(code: string): string {
  return crypto.createHash('sha256').update(code.trim().toLowerCase()).digest('hex')
}
