import { SignJWT, jwtVerify, type JWTPayload } from 'jose'
import { env } from '@/env'

const accessSecret = new TextEncoder().encode(env.JWT_ACCESS_SECRET)
const refreshSecret = new TextEncoder().encode(env.JWT_REFRESH_SECRET)

export type AccessClaims = JWTPayload & {
  sub: string
  email: string
  role: 'USER' | 'ADMIN'
  plan: 'FREE' | 'PRO' | 'TEAM'
}

export type RefreshClaims = JWTPayload & { sub: string; sid: string }

export async function signAccessToken(claims: Omit<AccessClaims, 'iat' | 'exp'>): Promise<string> {
  return new SignJWT(claims)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setIssuer('resumeforge-ai')
    .setAudience('resumeforge-ai')
    .setExpirationTime(`${env.ACCESS_TOKEN_TTL}s`)
    .sign(accessSecret)
}

export async function signRefreshToken(claims: Omit<RefreshClaims, 'iat' | 'exp'>): Promise<string> {
  return new SignJWT(claims)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setIssuer('resumeforge-ai')
    .setAudience('resumeforge-ai')
    .setExpirationTime(`${env.REFRESH_TOKEN_TTL}s`)
    .sign(refreshSecret)
}

export async function verifyAccessToken(token: string): Promise<AccessClaims> {
  const { payload } = await jwtVerify(token, accessSecret, {
    issuer: 'resumeforge-ai',
    audience: 'resumeforge-ai',
  })
  return payload as AccessClaims
}

export async function verifyRefreshToken(token: string): Promise<RefreshClaims> {
  const { payload } = await jwtVerify(token, refreshSecret, {
    issuer: 'resumeforge-ai',
    audience: 'resumeforge-ai',
  })
  return payload as RefreshClaims
}
