import bcrypt from 'bcryptjs'

const ROUNDS = 12

export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, ROUNDS)
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash)
}

/**
 * Enforce a strong password policy. Returns a list of failed rules (empty = ok).
 */
export function validatePasswordStrength(pw: string): string[] {
  const errors: string[] = []
  if (pw.length < 10) errors.push('Must be at least 10 characters')
  if (!/[a-z]/.test(pw)) errors.push('Must contain a lowercase letter')
  if (!/[A-Z]/.test(pw)) errors.push('Must contain an uppercase letter')
  if (!/[0-9]/.test(pw)) errors.push('Must contain a number')
  if (!/[^A-Za-z0-9]/.test(pw)) errors.push('Must contain a symbol')
  return errors
}
