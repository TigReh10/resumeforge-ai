import IORedis, { type Redis } from 'ioredis'
import { env } from '@/env'

const globalForRedis = globalThis as unknown as { redis?: Redis }

/**
 * Shared Redis connection. maxRetriesPerRequest must be null for BullMQ
 * compatibility on the connection used by queues/workers.
 */
export const redis: Redis =
  globalForRedis.redis ??
  new IORedis(env.REDIS_URL, {
    maxRetriesPerRequest: null,
    enableReadyCheck: true,
  })

if (env.NODE_ENV !== 'production') globalForRedis.redis = redis
