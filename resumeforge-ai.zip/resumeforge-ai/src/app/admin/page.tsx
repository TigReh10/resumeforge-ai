'use client'

import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { api } from '@/lib/api-client'

type Analytics = {
  totalUsers: number
  newUsers30d: number
  activeSubscriptions: number
  estimatedMrr: number
  planBreakdown: { planTier: string; _count: number }[]
  aiByType: { type: string; _count: number }[]
  aiTokens: { inputTokens: number | null; outputTokens: number | null }
}

export default function AdminDashboard() {
  const { data } = useQuery({ queryKey: ['admin-analytics'], queryFn: () => api.get<Analytics>('/admin/analytics') })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Platform Analytics</h1>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Total Users</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{data?.totalUsers ?? '—'}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">New (30d)</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{data?.newUsers30d ?? '—'}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Active Subs</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">{data?.activeSubscriptions ?? '—'}</p></CardContent></Card>
        <Card><CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Est. MRR</CardTitle></CardHeader><CardContent><p className="text-3xl font-bold">${data?.estimatedMrr ?? '—'}</p></CardContent></Card>
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Plan breakdown</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {data?.planBreakdown.map((p) => (
              <div key={p.planTier} className="flex justify-between text-sm"><span>{p.planTier}</span><span className="font-medium">{p._count}</span></div>
            ))}
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>AI usage by type</CardTitle></CardHeader>
          <CardContent className="space-y-2">
            {data?.aiByType.map((a) => (
              <div key={a.type} className="flex justify-between text-sm"><span>{a.type}</span><span className="font-medium">{a._count}</span></div>
            ))}
            <div className="mt-2 border-t pt-2 text-xs text-muted-foreground">
              Tokens: {(data?.aiTokens.inputTokens ?? 0).toLocaleString()} in / {(data?.aiTokens.outputTokens ?? 0).toLocaleString()} out
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
