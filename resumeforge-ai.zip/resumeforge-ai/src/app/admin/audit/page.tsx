'use client'

import { useQuery } from '@tanstack/react-query'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { api } from '@/lib/api-client'
import { formatDate } from '@/lib/utils'

type AuditEntry = {
  id: string
  action: string
  targetType: string | null
  targetId: string | null
  ip: string | null
  createdAt: string
  user: { email: string } | null
}

export default function AuditPage() {
  const { data } = useQuery({ queryKey: ['admin-audit'], queryFn: () => api.get<{ entries: AuditEntry[] }>('/admin/audit') })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Audit Log</h1>
      <Card>
        <CardContent className="overflow-x-auto p-0">
          <table className="w-full text-sm">
            <thead className="border-b text-left text-muted-foreground">
              <tr><th className="p-3">When</th><th className="p-3">Actor</th><th className="p-3">Action</th><th className="p-3">Target</th><th className="p-3">IP</th></tr>
            </thead>
            <tbody>
              {data?.entries.map((e) => (
                <tr key={e.id} className="border-b">
                  <td className="p-3 whitespace-nowrap">{formatDate(e.createdAt)}</td>
                  <td className="p-3">{e.user?.email ?? 'system'}</td>
                  <td className="p-3"><Badge variant="secondary">{e.action}</Badge></td>
                  <td className="p-3 text-muted-foreground">{e.targetType}{e.targetId ? `:${e.targetId.slice(0, 8)}` : ''}</td>
                  <td className="p-3 text-muted-foreground">{e.ip}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  )
}
