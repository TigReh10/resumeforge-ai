'use client'

import { useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { api } from '@/lib/api-client'
import { formatDate } from '@/lib/utils'
import { useToast } from '@/components/ui/toast'

type AdminUser = {
  id: string
  email: string
  name: string | null
  role: 'USER' | 'ADMIN'
  planTier: string
  suspended: boolean
  createdAt: string
}

export default function AdminUsersPage() {
  const qc = useQueryClient()
  const push = useToast((s) => s.push)
  const [q, setQ] = useState('')
  const { data } = useQuery({
    queryKey: ['admin-users', q],
    queryFn: () => api.get<{ users: AdminUser[]; total: number }>(`/admin/users?q=${encodeURIComponent(q)}`),
  })

  async function patch(id: string, body: Record<string, unknown>) {
    await api.patch(`/admin/users/${id}`, body)
    qc.invalidateQueries({ queryKey: ['admin-users'] })
    push({ title: 'User updated', variant: 'success' })
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Users</h1>
      <Input placeholder="Search by email or name…" value={q} onChange={(e) => setQ(e.target.value)} className="max-w-sm" />
      <Card>
        <CardContent className="overflow-x-auto p-0">
          <table className="w-full text-sm">
            <thead className="border-b text-left text-muted-foreground">
              <tr><th className="p-3">Email</th><th className="p-3">Role</th><th className="p-3">Plan</th><th className="p-3">Joined</th><th className="p-3">Status</th><th className="p-3">Actions</th></tr>
            </thead>
            <tbody>
              {data?.users.map((u) => (
                <tr key={u.id} className="border-b">
                  <td className="p-3">{u.email}<div className="text-xs text-muted-foreground">{u.name}</div></td>
                  <td className="p-3"><Badge variant={u.role === 'ADMIN' ? 'default' : 'secondary'}>{u.role}</Badge></td>
                  <td className="p-3">{u.planTier}</td>
                  <td className="p-3">{formatDate(u.createdAt)}</td>
                  <td className="p-3">{u.suspended ? <Badge variant="destructive">Suspended</Badge> : <Badge variant="success">Active</Badge>}</td>
                  <td className="p-3">
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => patch(u.id, { role: u.role === 'ADMIN' ? 'USER' : 'ADMIN' })}>{u.role === 'ADMIN' ? 'Demote' : 'Promote'}</Button>
                      <Button size="sm" variant={u.suspended ? 'outline' : 'destructive'} onClick={() => patch(u.id, { suspended: !u.suspended })}>{u.suspended ? 'Unsuspend' : 'Suspend'}</Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  )
}
