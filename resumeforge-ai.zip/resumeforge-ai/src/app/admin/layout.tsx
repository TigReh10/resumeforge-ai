'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { useQuery } from '@tanstack/react-query'
import { api } from '@/lib/api-client'
import { Toaster } from '@/components/ui/toast'
import type { CurrentUser } from '@/stores/auth-store'

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const { data, isError, isLoading } = useQuery({
    queryKey: ['me'],
    queryFn: () => api.get<CurrentUser>('/auth/me'),
    retry: false,
  })

  useEffect(() => {
    if (isError) router.replace('/login')
    else if (data && data.role !== 'ADMIN') router.replace('/dashboard')
  }, [data, isError, router])

  if (isLoading || !data || data.role !== 'ADMIN') {
    return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading…</div>
  }

  return (
    <div className="flex min-h-screen">
      <aside className="w-56 shrink-0 border-r bg-card/40 p-4">
        <p className="mb-6 px-2 text-lg font-bold">Admin</p>
        <nav className="space-y-1 text-sm">
          <Link href="/admin" className="block rounded-md px-3 py-2 hover:bg-accent">Dashboard</Link>
          <Link href="/admin/users" className="block rounded-md px-3 py-2 hover:bg-accent">Users</Link>
          <Link href="/admin/audit" className="block rounded-md px-3 py-2 hover:bg-accent">Audit Log</Link>
          <Link href="/dashboard" className="block rounded-md px-3 py-2 text-muted-foreground hover:bg-accent">← Back to app</Link>
        </nav>
      </aside>
      <main className="flex-1 overflow-y-auto p-6">{children}</main>
      <Toaster />
    </div>
  )
}
