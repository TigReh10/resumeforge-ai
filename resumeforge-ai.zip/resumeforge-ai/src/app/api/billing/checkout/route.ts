import type { NextRequest } from 'next/server'
import { ok, handleError, HttpError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { checkoutSchema } from '@/lib/validation'
import { stripe, ensureCustomer, priceIdFor } from '@/lib/stripe'
import { env } from '@/env'

export async function POST(req: NextRequest) {
  try {
    const auth = await authed()
    if (!stripe) throw new HttpError(400, 'Billing not configured', 'billing_disabled')
    const { plan, interval } = checkoutSchema.parse(await req.json())
    const customerId = await ensureCustomer(auth.id, auth.email)
    const session = await stripe.checkout.sessions.create({
      mode: 'subscription',
      customer: customerId,
      line_items: [{ price: priceIdFor(plan, interval), quantity: 1 }],
      success_url: `${env.APP_URL}/dashboard/billing?status=success`,
      cancel_url: `${env.APP_URL}/dashboard/billing?status=cancelled`,
      allow_promotion_codes: true,
      metadata: { userId: auth.id, plan },
      subscription_data: { metadata: { userId: auth.id } },
    })
    return ok({ url: session.url })
  } catch (err) {
    return handleError(err)
  }
}
