import { ok, handleError, HttpError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { stripe, ensureCustomer } from '@/lib/stripe'
import { env } from '@/env'

export async function POST() {
  try {
    const auth = await authed()
    if (!stripe) throw new HttpError(400, 'Billing not configured', 'billing_disabled')
    const customerId = await ensureCustomer(auth.id, auth.email)
    const session = await stripe.billingPortal.sessions.create({
      customer: customerId,
      return_url: `${env.APP_URL}/dashboard/billing`,
    })
    return ok({ url: session.url })
  } catch (err) {
    return handleError(err)
  }
}
