import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { ok, handleError, HttpError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { presignDownload, deleteObject } from '@/lib/storage/s3'
import { audit } from '@/lib/audit'

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const auth = await authed()
    const resume = await prisma.resume.findFirst({
      where: { id: params.id, userId: auth.id },
      include: {
        versions: { orderBy: { version: 'desc' } },
        analyses: { orderBy: { createdAt: 'desc' }, take: 10 },
      },
    })
    if (!resume) throw new HttpError(404, 'Resume not found', 'not_found')
    const downloadUrl = await presignDownload(resume.storageKey)
    return ok({ ...resume, downloadUrl })
  } catch (err) {
    return handleError(err)
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const auth = await authed()
    const resume = await prisma.resume.findFirst({ where: { id: params.id, userId: auth.id } })
    if (!resume) throw new HttpError(404, 'Resume not found', 'not_found')
    await deleteObject(resume.storageKey).catch(() => undefined)
    await prisma.resume.delete({ where: { id: resume.id } })
    await audit({ userId: auth.id, action: 'resume.delete', entity: 'Resume', entityId: resume.id })
    return ok({ deleted: true })
  } catch (err) {
    return handleError(err)
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const auth = await authed()
    const body = (await req.json()) as { title?: string; isArchived?: boolean }
    const resume = await prisma.resume.findFirst({ where: { id: params.id, userId: auth.id } })
    if (!resume) throw new HttpError(404, 'Resume not found', 'not_found')
    const updated = await prisma.resume.update({
      where: { id: resume.id },
      data: { title: body.title ?? resume.title, isArchived: body.isArchived ?? resume.isArchived },
      select: { id: true, title: true, isArchived: true },
    })
    return ok(updated)
  } catch (err) {
    return handleError(err)
  }
}
