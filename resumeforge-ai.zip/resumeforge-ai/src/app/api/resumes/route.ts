import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { ok, created, handleError, HttpError } from '@/lib/http'
import { authed, enforceRateLimit } from '@/lib/api-guard'
import { assertResumeQuota } from '@/lib/plans'
import { validateUpload, extractText, checksum, naiveStructure, FileValidationError } from '@/lib/resume/parse'
import { putObject } from '@/lib/storage/s3'
import { nanoid } from 'nanoid'
import { audit } from '@/lib/audit'

export const runtime = 'nodejs'

/** List the current user's resumes. */
export async function GET() {
  try {
    const auth = await authed()
    const resumes = await prisma.resume.findMany({
      where: { userId: auth.id, isArchived: false },
      orderBy: { updatedAt: 'desc' },
      select: { id: true, title: true, fileType: true, fileSize: true, createdAt: true, updatedAt: true },
    })
    return ok(resumes)
  } catch (err) {
    return handleError(err)
  }
}

/** Upload a new resume (multipart/form-data). */
export async function POST(req: NextRequest) {
  try {
    const auth = await authed()
    await enforceRateLimit('upload', auth.id)
    await assertResumeQuota(auth.id, auth.plan)

    const form = await req.formData()
    const file = form.get('file')
    const title = (form.get('title') as string) || 'Untitled resume'
    if (!(file instanceof File)) throw new HttpError(400, 'No file provided', 'no_file')

    const buf = Buffer.from(await file.arrayBuffer())
    let fileType
    try {
      fileType = validateUpload(file.name, buf)
    } catch (e) {
      if (e instanceof FileValidationError) throw new HttpError(422, e.message, 'invalid_file')
      throw e
    }

    const rawText = await extractText(buf, fileType)
    if (rawText.trim().length < 30) throw new HttpError(422, 'Could not extract text from file', 'empty_text')

    const sum = checksum(buf)
    const storageKey = `resumes/${auth.id}/${nanoid()}-${file.name}`
    await putObject(storageKey, buf, file.type || 'application/octet-stream')

    const resume = await prisma.resume.create({
      data: {
        userId: auth.id,
        title,
        fileType,
        storageKey,
        fileSize: buf.length,
        checksum: sum,
        rawText,
        structured: naiveStructure(rawText) as object,
      },
      select: { id: true, title: true, fileType: true, fileSize: true, createdAt: true },
    })
    await audit({ userId: auth.id, action: 'resume.upload', entity: 'Resume', entityId: resume.id })
    return created(resume)
  } catch (err) {
    return handleError(err)
  }
}
