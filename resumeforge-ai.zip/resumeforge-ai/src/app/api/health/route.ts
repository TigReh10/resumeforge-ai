import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { redis } from '@/lib/redis'
import { aiHealth } from '@/lib/ai'

export const dynamic = 'force-dynamic'

export async function GET() {
  const checks: Record<string, string> = {}
  try {
    await prisma.$queryRaw`SELECT 1`
    checks.database = 'ok'
  } catch {
    checks.database = 'down'
  }
  try {
    await redis.ping()
    checks.redis = 'ok'
  } catch {
    checks.redis = 'down'
  }
  const ai = aiHealth()
  const healthy = checks.database === 'ok' && checks.redis === 'ok'
  return NextResponse.json(
    { status: healthy ? 'healthy' : 'degraded', checks, ai, timestamp: new Date().toISOString() },
    { status: healthy ? 200 : 503 },
  )
}
