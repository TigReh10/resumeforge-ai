import { prisma } from '@/lib/prisma'
import { ok, handleError } from '@/lib/http'
import { requireUser } from '@/lib/auth/session'

export async function GET() {
  try {
    const auth = await requireUser()
    const user = await prisma.user.findUniqueOrThrow({
      where: { id: auth.id },
      select: {
        id: true,
        email: true,
        name: true,
        avatarUrl: true,
        role: true,
        planTier: true,
        emailVerified: true,
        twoFactorEnabled: true,
        createdAt: true,
      },
    })
    return ok(user)
  } catch (err) {
    return handleError(err)
  }
}
