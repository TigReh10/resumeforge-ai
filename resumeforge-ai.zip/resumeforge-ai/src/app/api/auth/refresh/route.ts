import { cookies } from 'next/headers'
import { ok, handleError, HttpError } from '@/lib/http'
import { rotateRefreshToken, requestMeta } from '@/lib/auth/session'
import { setAuthCookies, REFRESH_COOKIE } from '@/lib/auth/cookies'

export async function POST() {
  try {
    const refresh = cookies().get(REFRESH_COOKIE)?.value
    if (!refresh) throw new HttpError(401, 'No refresh token', 'no_refresh')
    const { accessToken, refreshToken } = await rotateRefreshToken(refresh, requestMeta())
    setAuthCookies(accessToken, refreshToken)
    return ok({ success: true })
  } catch (err) {
    return handleError(err)
  }
}
