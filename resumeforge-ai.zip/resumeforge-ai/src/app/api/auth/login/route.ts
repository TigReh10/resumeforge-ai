import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verifyPassword } from '@/lib/auth/password'
import { loginSchema } from '@/lib/validation'
import { ok, handleError, HttpError } from '@/lib/http'
import { enforceRateLimit, clientIp } from '@/lib/api-guard'
import { createSession, requestMeta } from '@/lib/auth/session'
import { setAuthCookies } from '@/lib/auth/cookies'
import { decryptSecret, verifyTotp, hashRecoveryCode } from '@/lib/auth/totp'
import { audit } from '@/lib/audit'

export async function POST(req: NextRequest) {
  try {
    await enforceRateLimit('auth', clientIp())
    const body = loginSchema.parse(await req.json())

    const user = await prisma.user.findUnique({ where: { email: body.email } })
    // Constant-ish response to avoid user enumeration.
    if (!user || !user.passwordHash || user.deletedAt) {
      throw new HttpError(401, 'Invalid email or password', 'invalid_credentials')
    }
    const valid = await verifyPassword(body.password, user.passwordHash)
    if (!valid) {
      await audit({ userId: user.id, action: 'auth.login.failed', ip: clientIp() })
      throw new HttpError(401, 'Invalid email or password', 'invalid_credentials')
    }

    // 2FA challenge
    if (user.twoFactorEnabled && user.twoFactorSecret) {
      if (!body.totp) throw new HttpError(401, 'Two-factor code required', 'totp_required')
      const secret = decryptSecret(user.twoFactorSecret)
      const okTotp = verifyTotp(secret, body.totp)
      let recovered = false
      if (!okTotp) {
        const codeHash = hashRecoveryCode(body.totp)
        if (user.twoFactorRecovery.includes(codeHash)) {
          recovered = true
          await prisma.user.update({
            where: { id: user.id },
            data: { twoFactorRecovery: user.twoFactorRecovery.filter((c) => c !== codeHash) },
          })
        }
      }
      if (!okTotp && !recovered) throw new HttpError(401, 'Invalid two-factor code', 'totp_invalid')
    }

    const meta = requestMeta()
    const { accessToken, refreshToken } = await createSession(user, meta)
    setAuthCookies(accessToken, refreshToken)
    await prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } })
    await audit({ userId: user.id, action: 'auth.login.success', ip: clientIp() })

    return ok({ id: user.id, email: user.email, name: user.name, role: user.role, plan: user.planTier })
  } catch (err) {
    return handleError(err)
  }
}
