import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { ok, handleError, HttpError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { enable2faSchema } from '@/lib/validation'
import { decryptSecret, verifyTotp, generateRecoveryCodes } from '@/lib/auth/totp'
import { audit } from '@/lib/audit'

/** Confirm the TOTP code and finalize 2FA, returning one-time recovery codes. */
export async function POST(req: NextRequest) {
  try {
    const auth = await authed('auth')
    const { totp } = enable2faSchema.parse(await req.json())
    const user = await prisma.user.findUniqueOrThrow({ where: { id: auth.id } })
    if (!user.twoFactorSecret) throw new HttpError(400, 'Start 2FA setup first', 'no_2fa_setup')
    if (!verifyTotp(decryptSecret(user.twoFactorSecret), totp)) {
      throw new HttpError(400, 'Invalid code', 'totp_invalid')
    }
    const { plaintext, hashes } = generateRecoveryCodes()
    await prisma.user.update({
      where: { id: user.id },
      data: { twoFactorEnabled: true, twoFactorRecovery: hashes },
    })
    await audit({ userId: user.id, action: 'auth.2fa_enabled' })
    return ok({ enabled: true, recoveryCodes: plaintext })
  } catch (err) {
    return handleError(err)
  }
}
