import { prisma } from '@/lib/prisma'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { audit } from '@/lib/audit'

export async function POST() {
  try {
    const auth = await authed('auth')
    await prisma.user.update({
      where: { id: auth.id },
      data: { twoFactorEnabled: false, twoFactorSecret: null, twoFactorRecovery: [] },
    })
    await audit({ userId: auth.id, action: 'auth.2fa_disabled' })
    return ok({ disabled: true })
  } catch (err) {
    return handleError(err)
  }
}
