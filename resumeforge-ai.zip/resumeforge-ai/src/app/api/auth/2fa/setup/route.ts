import { prisma } from '@/lib/prisma'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { generateTotpSecret, totpAuthUri, encryptSecret } from '@/lib/auth/totp'

/**
 * Begin 2FA enrollment: generate a secret, store it (encrypted, not yet enabled),
 * and return the otpauth URI for the authenticator QR code.
 */
export async function POST() {
  try {
    const auth = await authed('auth')
    const user = await prisma.user.findUniqueOrThrow({ where: { id: auth.id } })
    const secret = generateTotpSecret()
    await prisma.user.update({
      where: { id: user.id },
      data: { twoFactorSecret: encryptSecret(secret), twoFactorEnabled: false },
    })
    return ok({ otpauthUri: totpAuthUri(secret, user.email), secret })
  } catch (err) {
    return handleError(err)
  }
}
