import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { performResetSchema } from '@/lib/validation'
import { ok, handleError, HttpError } from '@/lib/http'
import { hashPassword, validatePasswordStrength } from '@/lib/auth/password'
import { sha256 } from '@/lib/crypto'
import { audit } from '@/lib/audit'

export async function POST(req: NextRequest) {
  try {
    const { token, password } = performResetSchema.parse(await req.json())
    const pwErrors = validatePasswordStrength(password)
    if (pwErrors.length) throw new HttpError(422, pwErrors.join('; '), 'weak_password')

    const record = await prisma.verificationToken.findUnique({ where: { tokenHash: sha256(token) } })
    if (!record || record.purpose !== 'PASSWORD_RESET' || record.usedAt || record.expiresAt < new Date()) {
      throw new HttpError(400, 'Invalid or expired reset link', 'invalid_token')
    }
    await prisma.$transaction([
      prisma.user.update({ where: { id: record.userId }, data: { passwordHash: await hashPassword(password) } }),
      prisma.verificationToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
      // Revoke all sessions on password change.
      prisma.session.updateMany({ where: { userId: record.userId, revokedAt: null }, data: { revokedAt: new Date() } }),
    ])
    await audit({ userId: record.userId, action: 'auth.password_reset' })
    return ok({ reset: true })
  } catch (err) {
    return handleError(err)
  }
}
