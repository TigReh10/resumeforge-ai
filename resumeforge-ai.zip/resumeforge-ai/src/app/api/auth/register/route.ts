import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { hashPassword, validatePasswordStrength } from '@/lib/auth/password'
import { registerSchema } from '@/lib/validation'
import { created, handleError, HttpError } from '@/lib/http'
import { enforceRateLimit, clientIp } from '@/lib/api-guard'
import { sha256, randomToken } from '@/lib/crypto'
import { sendEmail, verifyEmailTemplate } from '@/lib/email'
import { audit } from '@/lib/audit'
import { env } from '@/env'

export async function POST(req: NextRequest) {
  try {
    await enforceRateLimit('auth', clientIp())
    const body = registerSchema.parse(await req.json())

    const pwErrors = validatePasswordStrength(body.password)
    if (pwErrors.length) throw new HttpError(422, pwErrors.join('; '), 'weak_password')

    const existing = await prisma.user.findUnique({ where: { email: body.email } })
    if (existing) throw new HttpError(409, 'An account with this email already exists', 'email_taken')

    const user = await prisma.user.create({
      data: {
        email: body.email,
        name: body.name,
        passwordHash: await hashPassword(body.password),
      },
    })

    // Email verification token
    const token = randomToken()
    await prisma.verificationToken.create({
      data: {
        userId: user.id,
        tokenHash: sha256(token),
        purpose: 'EMAIL_VERIFY',
        expiresAt: new Date(Date.now() + 24 * 3600 * 1000),
      },
    })
    const link = `${env.APP_URL}/verify-email?token=${token}`
    await sendEmail(user.email, 'Verify your email', verifyEmailTemplate(link))
    await audit({ userId: user.id, action: 'auth.register', ip: clientIp() })

    return created({ id: user.id, email: user.email, needsVerification: true })
  } catch (err) {
    return handleError(err)
  }
}
