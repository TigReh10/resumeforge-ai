import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { verifyEmailSchema } from '@/lib/validation'
import { ok, handleError, HttpError } from '@/lib/http'
import { sha256 } from '@/lib/crypto'
import { audit } from '@/lib/audit'

export async function POST(req: NextRequest) {
  try {
    const { token } = verifyEmailSchema.parse(await req.json())
    const record = await prisma.verificationToken.findUnique({ where: { tokenHash: sha256(token) } })
    if (!record || record.purpose !== 'EMAIL_VERIFY' || record.usedAt || record.expiresAt < new Date()) {
      throw new HttpError(400, 'Invalid or expired verification link', 'invalid_token')
    }
    await prisma.$transaction([
      prisma.user.update({ where: { id: record.userId }, data: { emailVerified: new Date() } }),
      prisma.verificationToken.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
    ])
    await audit({ userId: record.userId, action: 'auth.email_verified' })
    return ok({ verified: true })
  } catch (err) {
    return handleError(err)
  }
}
