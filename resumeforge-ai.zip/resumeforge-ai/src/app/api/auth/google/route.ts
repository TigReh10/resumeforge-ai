import { NextResponse } from 'next/server'
import { env } from '@/env'
import { randomToken } from '@/lib/crypto'
import { cookies } from 'next/headers'

const GOOGLE_AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth'

/** Kick off Google OAuth: set a state cookie and redirect to Google's consent screen. */
export async function GET() {
  if (!env.GOOGLE_CLIENT_ID) {
    return NextResponse.json(
      { error: { code: 'oauth_disabled', message: 'Google login not configured' } },
      { status: 400 },
    )
  }
  const state = randomToken(16)
  cookies().set('rf_oauth_state', state, {
    httpOnly: true,
    secure: env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 600,
  })
  const params = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID,
    redirect_uri: env.GOOGLE_REDIRECT_URI,
    response_type: 'code',
    scope: 'openid email profile',
    state,
    access_type: 'offline',
    prompt: 'consent',
  })
  return NextResponse.redirect(`${GOOGLE_AUTH_URL}?${params.toString()}`)
}
