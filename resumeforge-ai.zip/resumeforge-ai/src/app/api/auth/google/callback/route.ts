import { NextResponse, type NextRequest } from 'next/server'
import { cookies } from 'next/headers'
import { env } from '@/env'
import { prisma } from '@/lib/prisma'
import { createSession, requestMeta } from '@/lib/auth/session'
import { setAuthCookies } from '@/lib/auth/cookies'
import { audit } from '@/lib/audit'
import { logger } from '@/lib/logger'

type GoogleUser = { sub: string; email: string; name?: string; picture?: string; email_verified?: boolean }

export async function GET(req: NextRequest) {
  try {
    const url = new URL(req.url)
    const code = url.searchParams.get('code')
    const state = url.searchParams.get('state')
    const savedState = cookies().get('rf_oauth_state')?.value
    if (!code || !state || state !== savedState) {
      return NextResponse.redirect(`${env.APP_URL}/login?error=oauth_state`)
    }

    // Exchange code for tokens
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: env.GOOGLE_CLIENT_ID,
        client_secret: env.GOOGLE_CLIENT_SECRET,
        redirect_uri: env.GOOGLE_REDIRECT_URI,
        grant_type: 'authorization_code',
      }),
    })
    if (!tokenRes.ok) throw new Error('Token exchange failed')
    const tokens = (await tokenRes.json()) as { access_token: string; refresh_token?: string; expires_in: number }

    const profileRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
    })
    const profile = (await profileRes.json()) as GoogleUser

    const user = await prisma.user.upsert({
      where: { email: profile.email },
      update: { name: profile.name, avatarUrl: profile.picture, emailVerified: new Date() },
      create: {
        email: profile.email,
        name: profile.name,
        avatarUrl: profile.picture,
        emailVerified: profile.email_verified ? new Date() : null,
      },
    })
    await prisma.oAuthAccount.upsert({
      where: { provider_providerAccountId: { provider: 'google', providerAccountId: profile.sub } },
      update: { accessToken: tokens.access_token, refreshToken: tokens.refresh_token, expiresAt: Math.floor(Date.now() / 1000) + tokens.expires_in },
      create: {
        userId: user.id,
        provider: 'google',
        providerAccountId: profile.sub,
        accessToken: tokens.access_token,
        refreshToken: tokens.refresh_token,
        expiresAt: Math.floor(Date.now() / 1000) + tokens.expires_in,
      },
    })

    const { accessToken, refreshToken } = await createSession(user, requestMeta())
    setAuthCookies(accessToken, refreshToken)
    cookies().delete('rf_oauth_state')
    await audit({ userId: user.id, action: 'auth.login.google' })
    return NextResponse.redirect(`${env.APP_URL}/dashboard`)
  } catch (err) {
    logger.error({ err }, 'Google OAuth callback failed')
    return NextResponse.redirect(`${env.APP_URL}/login?error=oauth`)
  }
}
