import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { requestResetSchema } from '@/lib/validation'
import { ok, handleError } from '@/lib/http'
import { enforceRateLimit, clientIp } from '@/lib/api-guard'
import { sha256, randomToken } from '@/lib/crypto'
import { sendEmail, resetPasswordTemplate } from '@/lib/email'
import { env } from '@/env'

export async function POST(req: NextRequest) {
  try {
    await enforceRateLimit('auth', clientIp())
    const { email } = requestResetSchema.parse(await req.json())
    const user = await prisma.user.findUnique({ where: { email } })
    // Always return success to avoid user enumeration.
    if (user && !user.deletedAt) {
      const token = randomToken()
      await prisma.verificationToken.create({
        data: {
          userId: user.id,
          tokenHash: sha256(token),
          purpose: 'PASSWORD_RESET',
          expiresAt: new Date(Date.now() + 3600 * 1000),
        },
      })
      const link = `${env.APP_URL}/reset-password?token=${token}`
      await sendEmail(user.email, 'Reset your password', resetPasswordTemplate(link))
    }
    return ok({ sent: true })
  } catch (err) {
    return handleError(err)
  }
}
