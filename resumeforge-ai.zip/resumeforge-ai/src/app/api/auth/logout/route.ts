import { cookies } from 'next/headers'
import { ok, handleError } from '@/lib/http'
import { revokeSession } from '@/lib/auth/session'
import { clearAuthCookies, REFRESH_COOKIE } from '@/lib/auth/cookies'

export async function POST() {
  try {
    const refresh = cookies().get(REFRESH_COOKIE)?.value
    if (refresh) await revokeSession(refresh)
    clearAuthCookies()
    return ok({ success: true })
  } catch (err) {
    return handleError(err)
  }
}
