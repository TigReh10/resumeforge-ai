import type { NextRequest } from 'next/server'
import { z } from 'zod'
import { ok, handleError } from '@/lib/http'
import { adminOnly } from '@/lib/api-guard'
import { prisma } from '@/lib/prisma'
import { audit } from '@/lib/audit'

const patchSchema = z.object({
  role: z.enum(['USER', 'ADMIN']).optional(),
  isSuspended: z.boolean().optional(),
  planTier: z.enum(['FREE', 'PRO', 'TEAM']).optional(),
})

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const admin = await adminOnly()
    const body = patchSchema.parse(await req.json())
    const updated = await prisma.user.update({
      where: { id: params.id },
      data: body,
      select: { id: true, role: true, isSuspended: true, planTier: true },
    })
    if (body.isSuspended) {
      await prisma.session.updateMany({ where: { userId: params.id, revokedAt: null }, data: { revokedAt: new Date() } })
    }
    await audit({ userId: admin.id, action: 'admin.user.update', entity: 'User', entityId: params.id, metadata: body })
    return ok(updated)
  } catch (err) {
    return handleError(err)
  }
}
