import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { adminOnly } from '@/lib/api-guard'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  try {
    await adminOnly()
    const url = new URL(req.url)
    const q = url.searchParams.get('q') ?? ''
    const page = Math.max(1, Number(url.searchParams.get('page') ?? 1))
    const pageSize = 25
    const where = q
      ? { OR: [{ email: { contains: q, mode: 'insensitive' as const } }, { name: { contains: q, mode: 'insensitive' as const } }] }
      : {}
    const [users, total] = await Promise.all([
      prisma.user.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        select: {
          id: true, email: true, name: true, role: true, planTier: true,
          emailVerified: true, isSuspended: true, createdAt: true, lastLoginAt: true,
          _count: { select: { resumes: true, analyses: true } },
        },
      }),
      prisma.user.count({ where }),
    ])
    return ok({ users, total, page, pageSize })
  } catch (err) {
    return handleError(err)
  }
}
