import { ok, handleError } from '@/lib/http'
import { adminOnly } from '@/lib/api-guard'
import { prisma } from '@/lib/prisma'
import { PLAN_LIMITS } from '@/lib/plans'

/** Platform-wide analytics: users, revenue (MRR estimate), AI usage, moderation. */
export async function GET() {
  try {
    await adminOnly()
    const since = new Date(Date.now() - 30 * 24 * 3600 * 1000)
    const [totalUsers, newUsers, activeSubs, planBreakdown, aiByType, aiTokens, recentSignups] = await Promise.all([
      prisma.user.count(),
      prisma.user.count({ where: { createdAt: { gte: since } } }),
      prisma.subscription.count({ where: { status: { in: ['ACTIVE', 'TRIALING'] } } }),
      prisma.subscription.groupBy({ by: ['planTier'], where: { status: { in: ['ACTIVE', 'TRIALING'] } }, _count: true }),
      prisma.analysis.groupBy({ by: ['type'], _count: true }),
      prisma.analysis.aggregate({ _sum: { inputTokens: true, outputTokens: true } }),
      prisma.user.groupBy({ by: ['planTier'], _count: true }),
    ])
    // Rough MRR estimate (list prices; real numbers come from Stripe reporting).
    const priceMonthly: Record<string, number> = { FREE: 0, PRO: 19, TEAM: 49 }
    const mrr = planBreakdown.reduce((sum, p) => sum + (priceMonthly[p.planTier] ?? 0) * p._count, 0)
    return ok({
      totalUsers,
      newUsers30d: newUsers,
      activeSubscriptions: activeSubs,
      planBreakdown,
      userPlanBreakdown: recentSignups,
      aiByType,
      aiTokens: aiTokens._sum,
      estimatedMrr: mrr,
      planLimits: PLAN_LIMITS,
    })
  } catch (err) {
    return handleError(err)
  }
}
