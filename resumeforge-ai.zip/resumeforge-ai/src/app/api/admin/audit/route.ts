import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { adminOnly } from '@/lib/api-guard'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  try {
    await adminOnly()
    const page = Math.max(1, Number(new URL(req.url).searchParams.get('page') ?? 1))
    const pageSize = 50
    const [logs, total] = await Promise.all([
      prisma.auditLog.findMany({
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        include: { user: { select: { email: true } } },
      }),
      prisma.auditLog.count(),
    ])
    return ok({ logs, total, page, pageSize })
  } catch (err) {
    return handleError(err)
  }
}
