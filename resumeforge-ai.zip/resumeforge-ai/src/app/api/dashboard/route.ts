import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { prisma } from '@/lib/prisma'

/** Aggregate dashboard data: counts, latest ATS scores, application funnel. */
export async function GET() {
  try {
    const auth = await authed()
    const [resumeCount, applicationCount, analyses, applications, subscription] = await Promise.all([
      prisma.resume.count({ where: { userId: auth.id, isArchived: false } }),
      prisma.application.count({ where: { userId: auth.id } }),
      prisma.analysis.findMany({
        where: { userId: auth.id, type: 'ATS_SCORE', score: { not: null } },
        orderBy: { createdAt: 'asc' },
        select: { score: true, createdAt: true },
      }),
      prisma.application.groupBy({ by: ['stage'], where: { userId: auth.id }, _count: true }),
      prisma.subscription.findUnique({ where: { userId: auth.id } }),
    ])
    const funnel = Object.fromEntries(applications.map((a) => [a.stage, a._count]))
    const atsTrend = analyses.map((a) => ({ score: a.score, date: a.createdAt }))
    const latestAts = atsTrend.at(-1)?.score ?? null
    return ok({
      resumeCount,
      applicationCount,
      latestAts,
      atsTrend,
      funnel,
      plan: auth.plan,
      subscription,
    })
  } catch (err) {
    return handleError(err)
  }
}
