import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { ok, created, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { jobPostingSchema } from '@/lib/validation'

function extractKeywords(text: string): string[] {
  const stop = new Set(['the', 'and', 'for', 'with', 'you', 'are', 'our', 'will', 'have', 'this', 'that', 'from'])
  const counts = new Map<string, number>()
  for (const w of text.toLowerCase().match(/[a-z][a-z+.#-]{2,}/g) ?? []) {
    if (stop.has(w)) continue
    counts.set(w, (counts.get(w) ?? 0) + 1)
  }
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 30).map(([w]) => w)
}

export async function GET() {
  try {
    const auth = await authed()
    const jobs = await prisma.jobPosting.findMany({
      where: { userId: auth.id },
      orderBy: { createdAt: 'desc' },
    })
    return ok(jobs)
  } catch (err) {
    return handleError(err)
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await authed()
    const body = jobPostingSchema.parse(await req.json())
    const job = await prisma.jobPosting.create({
      data: { ...body, userId: auth.id, keywords: extractKeywords(body.description) },
    })
    return created(job)
  } catch (err) {
    return handleError(err)
  }
}
