import type { NextRequest } from 'next/server'
import { NextResponse } from 'next/server'
import type Stripe from 'stripe'
import { stripe, planFromPriceId, intervalFromPriceId } from '@/lib/stripe'
import { prisma } from '@/lib/prisma'
import { env } from '@/env'
import { logger } from '@/lib/logger'

export const runtime = 'nodejs'
// Stripe needs the raw body to verify the signature.
export const dynamic = 'force-dynamic'

async function syncSubscription(sub: Stripe.Subscription) {
  const userId = (sub.metadata?.userId as string) || undefined
  const priceId = sub.items.data[0]?.price.id
  const plan = planFromPriceId(priceId)
  const interval = intervalFromPriceId(priceId)
  const statusMap: Record<string, 'ACTIVE' | 'PAST_DUE' | 'CANCELED' | 'TRIALING' | 'INCOMPLETE'> = {
    active: 'ACTIVE',
    trialing: 'TRIALING',
    past_due: 'PAST_DUE',
    canceled: 'CANCELED',
    unpaid: 'PAST_DUE',
    incomplete: 'INCOMPLETE',
    incomplete_expired: 'CANCELED',
  }
  const status = statusMap[sub.status] ?? 'INCOMPLETE'
  const customerId = typeof sub.customer === 'string' ? sub.customer : sub.customer.id

  const existing = userId
    ? await prisma.subscription.findUnique({ where: { userId } })
    : await prisma.subscription.findFirst({ where: { stripeCustomerId: customerId } })
  const targetUserId = userId ?? existing?.userId
  if (!targetUserId) {
    logger.warn({ customerId }, 'No user mapped to subscription')
    return
  }

  await prisma.subscription.upsert({
    where: { userId: targetUserId },
    create: {
      userId: targetUserId,
      stripeCustomerId: customerId,
      stripeSubscriptionId: sub.id,
      stripePriceId: priceId,
      planTier: plan,
      status,
      interval: interval ?? undefined,
      currentPeriodEnd: new Date(sub.current_period_end * 1000),
      cancelAtPeriodEnd: sub.cancel_at_period_end,
    },
    update: {
      stripeSubscriptionId: sub.id,
      stripePriceId: priceId,
      planTier: plan,
      status,
      interval: interval ?? undefined,
      currentPeriodEnd: new Date(sub.current_period_end * 1000),
      cancelAtPeriodEnd: sub.cancel_at_period_end,
    },
  })
  // Keep denormalized plan on user for fast auth reads.
  await prisma.user.update({
    where: { id: targetUserId },
    data: { planTier: status === 'ACTIVE' || status === 'TRIALING' ? plan : 'FREE' },
  })
}

export async function POST(req: NextRequest) {
  if (!stripe) return NextResponse.json({ received: true })
  const sig = req.headers.get('stripe-signature')
  const raw = await req.text()
  let event: Stripe.Event
  try {
    event = stripe.webhooks.constructEvent(raw, sig!, env.STRIPE_WEBHOOK_SECRET)
  } catch (err) {
    logger.warn({ err }, 'Invalid Stripe webhook signature')
    return NextResponse.json({ error: 'invalid signature' }, { status: 400 })
  }

  // Idempotency: skip already-processed events.
  const seen = await prisma.webhookEvent.findUnique({ where: { eventId: event.id } })
  if (seen) return NextResponse.json({ received: true, duplicate: true })
  await prisma.webhookEvent.create({ data: { eventId: event.id, type: event.type } })

  try {
    switch (event.type) {
      case 'customer.subscription.created':
      case 'customer.subscription.updated':
      case 'customer.subscription.deleted':
        await syncSubscription(event.data.object as Stripe.Subscription)
        break
      case 'checkout.session.completed': {
        const session = event.data.object as Stripe.Checkout.Session
        if (session.subscription) {
          const sub = await stripe.subscriptions.retrieve(session.subscription as string)
          await syncSubscription(sub)
        }
        break
      }
      default:
        break
    }
  } catch (err) {
    logger.error({ err, type: event.type }, 'Webhook handler error')
    return NextResponse.json({ error: 'handler error' }, { status: 500 })
  }
  return NextResponse.json({ received: true })
}
