import type { NextRequest } from 'next/server'
import { prisma } from '@/lib/prisma'
import { ok, created, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { applicationSchema } from '@/lib/validation'

export async function GET() {
  try {
    const auth = await authed()
    const apps = await prisma.application.findMany({
      where: { userId: auth.id },
      orderBy: { updatedAt: 'desc' },
      include: { jobPosting: { select: { title: true, company: true } }, resume: { select: { title: true } } },
    })
    return ok(apps)
  } catch (err) {
    return handleError(err)
  }
}

export async function POST(req: NextRequest) {
  try {
    const auth = await authed()
    const body = applicationSchema.parse(await req.json())
    const app = await prisma.application.create({
      data: {
        userId: auth.id,
        resumeId: body.resumeId,
        jobPostingId: body.jobPostingId,
        stage: body.stage,
        notes: body.notes,
        appliedAt: body.stage === 'APPLIED' ? new Date() : null,
      },
    })
    return created(app)
  } catch (err) {
    return handleError(err)
  }
}
