import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { interviewSchema } from '@/lib/validation'
import { runInterviewPrep } from '@/lib/services/analysis'

export async function POST(req: NextRequest) {
  try {
    const auth = await authed('ai')
    const { resumeId, jobPostingId } = interviewSchema.parse(await req.json())
    const result = await runInterviewPrep({ userId: auth.id, plan: auth.plan, resumeId, jobPostingId })
    return ok(result)
  } catch (err) {
    return handleError(err)
  }
}
