import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { analyzeSchema } from '@/lib/validation'
import { runAtsAnalysis } from '@/lib/services/analysis'

/** Synchronous ATS analysis (fast path). For very heavy batches, use /api/ai/jobs. */
export async function POST(req: NextRequest) {
  try {
    const auth = await authed('ai')
    const { resumeId } = analyzeSchema.parse(await req.json())
    const analysis = await runAtsAnalysis({ userId: auth.id, plan: auth.plan, resumeId })
    return ok(analysis)
  } catch (err) {
    return handleError(err)
  }
}
