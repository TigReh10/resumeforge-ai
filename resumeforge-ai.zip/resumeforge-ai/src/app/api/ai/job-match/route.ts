import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { jobMatchSchema } from '@/lib/validation'
import { runJobMatch } from '@/lib/services/analysis'
import { prisma } from '@/lib/prisma'

export async function POST(req: NextRequest) {
  try {
    const auth = await authed('ai')
    const { resumeId, jobPostingId } = jobMatchSchema.parse(await req.json())
    const analysis = await runJobMatch({ userId: auth.id, plan: auth.plan, resumeId, jobPostingId })
    // Update any linked application's match score.
    await prisma.application.updateMany({
      where: { userId: auth.id, resumeId, jobPostingId },
      data: { matchScore: analysis.score ?? undefined },
    })
    return ok(analysis)
  } catch (err) {
    return handleError(err)
  }
}
