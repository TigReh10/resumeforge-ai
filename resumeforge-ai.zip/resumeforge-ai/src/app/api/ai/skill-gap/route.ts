import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { skillGapSchema } from '@/lib/validation'
import { runSkillGap } from '@/lib/services/analysis'

export async function POST(req: NextRequest) {
  try {
    const auth = await authed('ai')
    const { resumeId, jobPostingId } = skillGapSchema.parse(await req.json())
    const result = await runSkillGap({ userId: auth.id, plan: auth.plan, resumeId, jobPostingId })
    return ok(result)
  } catch (err) {
    return handleError(err)
  }
}
