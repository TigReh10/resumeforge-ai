import type { NextRequest } from 'next/server'
import { z } from 'zod'
import { prisma } from '@/lib/prisma'
import { ok, created, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { enqueueAiJob } from '@/lib/queue'
import type { AnalysisType } from '@prisma/client'

const enqueueSchema = z.object({
  type: z.enum([
    'ATS_SCORE', 'JOB_MATCH', 'COVER_LETTER', 'LINKEDIN',
    'INTERVIEW', 'SKILL_GAP', 'CAREER_ROADMAP', 'REWRITE',
  ]),
  payload: z.record(z.any()),
})

/** Enqueue a heavy AI job for async processing by the worker. */
export async function POST(req: NextRequest) {
  try {
    const auth = await authed('ai')
    const { type, payload } = enqueueSchema.parse(await req.json())
    const aiJob = await prisma.aiJob.create({
      data: { userId: auth.id, type: type as AnalysisType, status: 'QUEUED', payload: payload as object },
    })
    await enqueueAiJob({ aiJobId: aiJob.id, userId: auth.id, plan: auth.plan, type: type as AnalysisType, payload })
    return created({ jobId: aiJob.id, status: aiJob.status })
  } catch (err) {
    return handleError(err)
  }
}

/** Poll job status. */
export async function GET(req: NextRequest) {
  try {
    const auth = await authed()
    const id = new URL(req.url).searchParams.get('id')
    if (!id) return ok(await prisma.aiJob.findMany({ where: { userId: auth.id }, orderBy: { createdAt: 'desc' }, take: 20 }))
    const job = await prisma.aiJob.findFirst({ where: { id, userId: auth.id } })
    return ok(job)
  } catch (err) {
    return handleError(err)
  }
}
