import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { coverLetterSchema } from '@/lib/validation'
import { generateCoverLetter } from '@/lib/services/analysis'

export async function POST(req: NextRequest) {
  try {
    const auth = await authed('ai')
    const body = coverLetterSchema.parse(await req.json())
    const letter = await generateCoverLetter({ userId: auth.id, plan: auth.plan, ...body })
    return ok(letter)
  } catch (err) {
    return handleError(err)
  }
}
