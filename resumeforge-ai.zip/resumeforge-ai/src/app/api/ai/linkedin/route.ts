import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { linkedinSchema } from '@/lib/validation'
import { runLinkedinOptimize } from '@/lib/services/analysis'

export async function POST(req: NextRequest) {
  try {
    const auth = await authed('ai')
    const { profileText } = linkedinSchema.parse(await req.json())
    const result = await runLinkedinOptimize({ userId: auth.id, plan: auth.plan, profileText })
    return ok(result)
  } catch (err) {
    return handleError(err)
  }
}
