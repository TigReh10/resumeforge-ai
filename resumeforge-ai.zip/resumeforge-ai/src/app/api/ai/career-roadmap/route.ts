import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { roadmapSchema } from '@/lib/validation'
import { runCareerRoadmap } from '@/lib/services/analysis'

export async function POST(req: NextRequest) {
  try {
    const auth = await authed('ai')
    const { resumeId, goal } = roadmapSchema.parse(await req.json())
    const result = await runCareerRoadmap({ userId: auth.id, plan: auth.plan, resumeId, goal })
    return ok(result)
  } catch (err) {
    return handleError(err)
  }
}
