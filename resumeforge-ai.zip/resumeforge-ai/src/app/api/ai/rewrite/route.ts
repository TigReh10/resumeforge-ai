import type { NextRequest } from 'next/server'
import { ok, handleError } from '@/lib/http'
import { authed } from '@/lib/api-guard'
import { rewriteSchema } from '@/lib/validation'
import { rewriteResume } from '@/lib/services/analysis'

export async function POST(req: NextRequest) {
  try {
    const auth = await authed('ai')
    const { resumeId, jobPostingId } = rewriteSchema.parse(await req.json())
    const version = await rewriteResume({ userId: auth.id, plan: auth.plan, resumeId, jobPostingId })
    return ok(version)
  } catch (err) {
    return handleError(err)
  }
}
