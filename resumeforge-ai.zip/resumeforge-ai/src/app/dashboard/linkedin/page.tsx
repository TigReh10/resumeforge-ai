'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { api, ApiError } from '@/lib/api-client'
import { useToast } from '@/components/ui/toast'

type LinkedinResult = {
  result: {
    analysis: Record<string, string>
    improvedHeadline: string
    improvedAbout: string
    recruiterTips: string[]
  }
}

export default function LinkedinPage() {
  const push = useToast((s) => s.push)
  const [profileText, setProfileText] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<LinkedinResult['result'] | null>(null)

  async function run() {
    if (profileText.length < 20) return
    setLoading(true)
    try {
      const res = await api.post<LinkedinResult>('/ai/linkedin', { profileText })
      setResult(res.result)
    } catch (err) {
      push({ title: 'Failed', description: err instanceof ApiError ? err.message : '', variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">LinkedIn Optimizer</h1>
      <Card>
        <CardContent className="space-y-3 pt-6">
          <Textarea value={profileText} onChange={(e) => setProfileText(e.target.value)} placeholder="Paste your LinkedIn headline, about, and experience…" className="min-h-[200px]" />
          <Button onClick={run} disabled={profileText.length < 20 || loading}>{loading ? 'Optimizing…' : 'Optimize profile'}</Button>
        </CardContent>
      </Card>
      {result && (
        <div className="space-y-4">
          <Card><CardHeader><CardTitle>Improved headline</CardTitle></CardHeader><CardContent><p className="text-sm">{result.improvedHeadline}</p></CardContent></Card>
          <Card><CardHeader><CardTitle>Improved about</CardTitle></CardHeader><CardContent><p className="whitespace-pre-wrap text-sm text-muted-foreground">{result.improvedAbout}</p></CardContent></Card>
          <Card><CardHeader><CardTitle>Recruiter tips</CardTitle></CardHeader><CardContent><ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">{result.recruiterTips.map((t, i) => <li key={i}>{t}</li>)}</ul></CardContent></Card>
        </div>
      )}
    </div>
  )
}
