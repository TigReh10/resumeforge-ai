'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { ResumeSelect } from '@/components/dashboard/resume-select'
import { api, ApiError } from '@/lib/api-client'
import { useToast } from '@/components/ui/toast'

type Roadmap = {
  result: {
    targetRole: string
    milestones: { timeframe: string; focus: string; actions: string[] }[]
    skillsToLearn: string[]
    certifications: string[]
  }
}

export default function CareerRoadmapPage() {
  const push = useToast((s) => s.push)
  const [resumeId, setResumeId] = useState('')
  const [targetRole, setTargetRole] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<Roadmap['result'] | null>(null)

  async function run() {
    if (!resumeId || !targetRole) return
    setLoading(true)
    try {
      const res = await api.post<Roadmap>('/ai/career-roadmap', { resumeId, targetRole })
      setResult(res.result)
    } catch (err) {
      push({ title: 'Failed', description: err instanceof ApiError ? err.message : '', variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Career Roadmap</h1>
      <Card>
        <CardContent className="space-y-3 pt-6">
          <ResumeSelect value={resumeId} onChange={setResumeId} />
          <div className="space-y-2"><Label>Target role</Label><Input value={targetRole} onChange={(e) => setTargetRole(e.target.value)} placeholder="Staff Engineer" /></div>
          <Button onClick={run} disabled={!resumeId || !targetRole || loading}>{loading ? 'Building…' : 'Generate roadmap'}</Button>
        </CardContent>
      </Card>
      {result && (
        <div className="space-y-4">
          {result.milestones.map((m, i) => (
            <Card key={i}>
              <CardHeader><CardTitle className="flex items-center gap-2"><Badge>{m.timeframe}</Badge>{m.focus}</CardTitle></CardHeader>
              <CardContent><ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">{m.actions.map((a, j) => <li key={j}>{a}</li>)}</ul></CardContent>
            </Card>
          ))}
          <Card>
            <CardHeader><CardTitle>Skills &amp; certifications</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <div className="flex flex-wrap gap-2">{result.skillsToLearn.map((s) => <Badge key={s} variant="outline">{s}</Badge>)}</div>
              <div className="flex flex-wrap gap-2">{result.certifications.map((c) => <Badge key={c} variant="secondary">{c}</Badge>)}</div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
