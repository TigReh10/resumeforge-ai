'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { useBuilderStore, type ResumeSection } from '@/stores/builder-store'
import { cn } from '@/lib/utils'

const TEMPLATES: { id: 'modern' | 'classic' | 'minimal' | 'technical'; label: string }[] = [
  { id: 'modern', label: 'Modern' },
  { id: 'classic', label: 'Classic' },
  { id: 'minimal', label: 'Minimal' },
  { id: 'technical', label: 'Technical' },
]

function Preview({ title, sections, template }: { title: string; sections: ResumeSection[]; template: string }) {
  return (
    <div className={cn('rounded-lg border bg-white p-8 text-slate-800 shadow-inner', template === 'minimal' && 'font-light')}>
      <h1 className={cn('text-2xl font-bold', template === 'modern' && 'text-primary', template === 'classic' && 'border-b pb-2')}>{title}</h1>
      {sections.map((s) => (
        <section key={s.id} className="mt-4">
          <h2 className={cn('text-sm font-semibold uppercase tracking-wide', template === 'technical' && 'text-primary')}>{s.title}</h2>
          <p className="mt-1 whitespace-pre-wrap text-sm">{s.content || <span className="text-slate-400">…</span>}</p>
        </section>
      ))}
    </div>
  )
}

export default function BuilderPage() {
  const store = useBuilderStore()
  const [dragIndex, setDragIndex] = useState<number | null>(null)

  function onDrop(index: number) {
    if (dragIndex !== null && dragIndex !== index) store.reorder(dragIndex, index)
    setDragIndex(null)
  }

  function exportText() {
    const text = `${store.title}\n\n` + store.sections.map((s) => `${s.title.toUpperCase()}\n${s.content}`).join('\n\n')
    const blob = new Blob([text], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${store.title}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Resume Builder</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => window.print()}>Export PDF (print)</Button>
          <Button onClick={exportText}>Export TXT</Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {TEMPLATES.map((t) => (
          <Badge
            key={t.id}
            onClick={() => store.setTemplate(t.id)}
            variant={store.template === t.id ? 'default' : 'outline'}
            className="cursor-pointer"
          >
            {t.label}
          </Badge>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Editor</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            <Input value={store.title} onChange={(e) => store.setTitle(e.target.value)} placeholder="Resume title" />
            {store.sections.map((s, i) => (
              <div
                key={s.id}
                draggable
                onDragStart={() => setDragIndex(i)}
                onDragOver={(e) => e.preventDefault()}
                onDrop={() => onDrop(i)}
                className="rounded-lg border p-3"
              >
                <div className="mb-2 flex items-center justify-between">
                  <span className="cursor-grab text-sm font-medium">☰ {s.title}</span>
                  <button onClick={() => store.removeSection(s.id)} className="text-xs text-destructive">Remove</button>
                </div>
                <Textarea value={s.content} onChange={(e) => store.updateSection(s.id, e.target.value)} />
              </div>
            ))}
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={() => store.addSection('projects')}>+ Projects</Button>
              <Button size="sm" variant="outline" onClick={() => store.addSection('custom')}>+ Custom</Button>
            </div>
          </CardContent>
        </Card>
        <div>
          <p className="mb-2 text-sm font-medium text-muted-foreground">Live preview</p>
          <Preview title={store.title} sections={store.sections} template={store.template} />
        </div>
      </div>
    </div>
  )
}
