'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useQuery } from '@tanstack/react-query'
import { Sidebar } from '@/components/dashboard/sidebar'
import { Topbar } from '@/components/dashboard/topbar'
import { Toaster } from '@/components/ui/toast'
import { api } from '@/lib/api-client'
import { useAuthStore, type CurrentUser } from '@/stores/auth-store'

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  const setUser = useAuthStore((s) => s.setUser)
  const { data, isError, isLoading } = useQuery({
    queryKey: ['me'],
    queryFn: () => api.get<CurrentUser>('/auth/me'),
    retry: false,
  })

  useEffect(() => {
    if (data) setUser(data)
    if (isError) router.replace('/login')
  }, [data, isError, router, setUser])

  if (isLoading || !data) {
    return <div className="flex min-h-screen items-center justify-center text-muted-foreground">Loading…</div>
  }

  return (
    <div className="flex min-h-screen">
      <Sidebar />
      <div className="flex flex-1 flex-col">
        <Topbar />
        <main className="flex-1 overflow-y-auto p-6">{children}</main>
      </div>
      <Toaster />
    </div>
  )
}
