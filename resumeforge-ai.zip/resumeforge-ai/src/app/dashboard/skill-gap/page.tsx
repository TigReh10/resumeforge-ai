'use client'

import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { ResumeSelect } from '@/components/dashboard/resume-select'
import { api, ApiError } from '@/lib/api-client'
import { useToast } from '@/components/ui/toast'

type SkillGap = {
  result: {
    readiness: number
    have: string[]
    gaps: { skill: string; importance: string; howToLearn: string }[]
    summary: string
  }
}

export default function SkillGapPage() {
  const qc = useQueryClient()
  const push = useToast((s) => s.push)
  const [resumeId, setResumeId] = useState('')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<SkillGap['result'] | null>(null)

  async function run() {
    if (!resumeId || description.length < 20) return
    setLoading(true)
    try {
      const job = await api.post<{ id: string }>('/jobs', { title: title || 'Target role', description })
      qc.invalidateQueries({ queryKey: ['jobs'] })
      const res = await api.post<SkillGap>('/ai/skill-gap', { resumeId, jobPostingId: job.id })
      setResult(res.result)
    } catch (err) {
      push({ title: 'Failed', description: err instanceof ApiError ? err.message : '', variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Skill-Gap Analysis</h1>
      <Card>
        <CardContent className="space-y-3 pt-6">
          <ResumeSelect value={resumeId} onChange={setResumeId} />
          <div className="space-y-2"><Label>Target role</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} /></div>
          <div className="space-y-2"><Label>Job description</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} /></div>
          <Button onClick={run} disabled={!resumeId || description.length < 20 || loading}>{loading ? 'Analyzing…' : 'Analyze gaps'}</Button>
        </CardContent>
      </Card>
      {result && (
        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle>Readiness: {result.readiness}%</CardTitle></CardHeader>
            <CardContent><Progress value={result.readiness} /><p className="mt-2 text-sm text-muted-foreground">{result.summary}</p></CardContent>
          </Card>
          <Card>
            <CardHeader><CardTitle>Gaps to close</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {result.gaps.map((g, i) => (
                <div key={i} className="rounded-lg border p-3">
                  <div className="flex items-center gap-2"><Badge variant={g.importance === 'high' ? 'destructive' : 'warning'}>{g.importance}</Badge><span className="font-medium">{g.skill}</span></div>
                  <p className="mt-1 text-sm text-muted-foreground">{g.howToLearn}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
