'use client'

import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { ResumeSelect } from '@/components/dashboard/resume-select'
import { api, ApiError } from '@/lib/api-client'
import { useToast } from '@/components/ui/toast'

const TONES = ['professional', 'enthusiastic', 'formal', 'conversational', 'concise']

export default function CoverLetterPage() {
  const qc = useQueryClient()
  const push = useToast((s) => s.push)
  const [resumeId, setResumeId] = useState('')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [tone, setTone] = useState('professional')
  const [loading, setLoading] = useState(false)
  const [letter, setLetter] = useState('')

  async function run() {
    if (!resumeId || description.length < 20) return
    setLoading(true)
    try {
      const job = await api.post<{ id: string }>('/jobs', { title: title || 'Untitled role', description })
      qc.invalidateQueries({ queryKey: ['jobs'] })
      const res = await api.post<{ content: string }>('/ai/cover-letter', { resumeId, jobPostingId: job.id, tone })
      setLetter(res.content)
    } catch (err) {
      push({ title: 'Generation failed', description: err instanceof ApiError ? err.message : '', variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Cover Letter Generator</h1>
      <Card>
        <CardContent className="space-y-3 pt-6">
          <ResumeSelect value={resumeId} onChange={setResumeId} />
          <div className="space-y-2"><Label>Job title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} /></div>
          <div className="space-y-2"><Label>Job description</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} /></div>
          <div className="space-y-2">
            <Label>Tone</Label>
            <select className="flex h-10 w-full rounded-md border border-input bg-background px-3 text-sm" value={tone} onChange={(e) => setTone(e.target.value)}>
              {TONES.map((t) => <option key={t} value={t} className="capitalize">{t}</option>)}
            </select>
          </div>
          <Button onClick={run} disabled={!resumeId || description.length < 20 || loading}>{loading ? 'Writing…' : 'Generate cover letter'}</Button>
        </CardContent>
      </Card>
      {letter && (
        <Card>
          <CardHeader><CardTitle>Your cover letter</CardTitle></CardHeader>
          <CardContent>
            <Textarea value={letter} onChange={(e) => setLetter(e.target.value)} className="min-h-[360px]" />
            <Button className="mt-3" variant="outline" onClick={() => navigator.clipboard.writeText(letter)}>Copy to clipboard</Button>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
