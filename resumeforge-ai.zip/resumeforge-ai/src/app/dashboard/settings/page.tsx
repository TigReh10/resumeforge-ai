'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { api, ApiError } from '@/lib/api-client'
import { useAuthStore } from '@/stores/auth-store'
import { useToast } from '@/components/ui/toast'

export default function SettingsPage() {
  const user = useAuthStore((s) => s.user)
  const push = useToast((s) => s.push)
  const [otpauth, setOtpauth] = useState<string | null>(null)
  const [code, setCode] = useState('')
  const [recovery, setRecovery] = useState<string[] | null>(null)

  async function start2fa() {
    const res = await api.post<{ otpauthUri: string }>('/auth/2fa/setup')
    setOtpauth(res.otpauthUri)
  }
  async function enable2fa() {
    try {
      const res = await api.post<{ recoveryCodes: string[] }>('/auth/2fa/enable', { totp: code })
      setRecovery(res.recoveryCodes)
      push({ title: '2FA enabled', variant: 'success' })
    } catch (err) {
      push({ title: 'Invalid code', description: err instanceof ApiError ? err.message : '', variant: 'error' })
    }
  }
  async function disable2fa() {
    await api.post('/auth/2fa/disable')
    setOtpauth(null)
    setRecovery(null)
    push({ title: '2FA disabled', variant: 'success' })
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Settings</h1>
      <Card>
        <CardHeader><CardTitle>Account</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          <p><span className="text-muted-foreground">Email:</span> {user?.email}</p>
          <p><span className="text-muted-foreground">Plan:</span> <Badge variant="secondary">{user?.planTier}</Badge></p>
          <p><span className="text-muted-foreground">Email verified:</span> {user?.emailVerified ? 'Yes' : 'No'}</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>Two-Factor Authentication</CardTitle>
          <CardDescription>Add an extra layer of security with an authenticator app.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {user?.twoFactorEnabled ? (
            <Button variant="destructive" onClick={disable2fa}>Disable 2FA</Button>
          ) : !otpauth ? (
            <Button onClick={start2fa}>Set up 2FA</Button>
          ) : (
            <div className="space-y-3">
              <p className="break-all rounded bg-muted p-2 text-xs">{otpauth}</p>
              <p className="text-xs text-muted-foreground">Add this URI to your authenticator, then enter the 6-digit code.</p>
              <div className="flex gap-2">
                <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="123456" />
                <Button onClick={enable2fa}>Verify &amp; enable</Button>
              </div>
            </div>
          )}
          {recovery && (
            <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3">
              <p className="mb-2 text-sm font-medium">Save your recovery codes</p>
              <div className="grid grid-cols-2 gap-1 font-mono text-xs">{recovery.map((c) => <span key={c}>{c}</span>)}</div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
