'use client'

import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { ResumeSelect } from '@/components/dashboard/resume-select'
import { api, ApiError } from '@/lib/api-client'
import { useToast } from '@/components/ui/toast'

type QA = { question: string; suggestedAnswer: string }
type Result = { result: { behavioral: QA[]; technical: QA[]; followUps: string[] } }

function QAList({ items }: { items: QA[] }) {
  return (
    <div className="space-y-3">
      {items.map((qa, i) => (
        <div key={i} className="rounded-lg border p-3">
          <p className="font-medium">{qa.question}</p>
          <p className="mt-1 text-sm text-muted-foreground">{qa.suggestedAnswer}</p>
        </div>
      ))}
    </div>
  )
}

export default function InterviewPage() {
  const qc = useQueryClient()
  const push = useToast((s) => s.push)
  const [resumeId, setResumeId] = useState('')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<Result['result'] | null>(null)

  async function run() {
    if (!resumeId || description.length < 20) return
    setLoading(true)
    try {
      const job = await api.post<{ id: string }>('/jobs', { title: title || 'Untitled role', description })
      qc.invalidateQueries({ queryKey: ['jobs'] })
      const res = await api.post<Result>('/ai/interview', { resumeId, jobPostingId: job.id })
      setResult(res.result)
    } catch (err) {
      push({ title: 'Failed', description: err instanceof ApiError ? err.message : '', variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Interview Preparation</h1>
      <Card>
        <CardContent className="space-y-3 pt-6">
          <ResumeSelect value={resumeId} onChange={setResumeId} />
          <div className="space-y-2"><Label>Job title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} /></div>
          <div className="space-y-2"><Label>Job description</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} /></div>
          <Button onClick={run} disabled={!resumeId || description.length < 20 || loading}>{loading ? 'Preparing…' : 'Generate questions'}</Button>
        </CardContent>
      </Card>
      {result && (
        <Tabs defaultValue="behavioral">
          <TabsList>
            <TabsTrigger value="behavioral">Behavioral</TabsTrigger>
            <TabsTrigger value="technical">Technical</TabsTrigger>
            <TabsTrigger value="followups">Follow-ups</TabsTrigger>
          </TabsList>
          <TabsContent value="behavioral"><QAList items={result.behavioral} /></TabsContent>
          <TabsContent value="technical"><QAList items={result.technical} /></TabsContent>
          <TabsContent value="followups">
            <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">{result.followUps.map((f, i) => <li key={i}>{f}</li>)}</ul>
          </TabsContent>
        </Tabs>
      )}
    </div>
  )
}
