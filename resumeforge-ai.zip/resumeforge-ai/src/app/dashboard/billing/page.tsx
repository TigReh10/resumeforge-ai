'use client'

import { Suspense } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { api } from '@/lib/api-client'

type Sub = { planTier: string; status: string; currentPeriodEnd?: string; cancelAtPeriodEnd?: boolean } | null

const PLANS: { plan: 'PRO' | 'TEAM'; name: string; monthly: number; annual: number }[] = [
  { plan: 'PRO', name: 'Pro', monthly: 19, annual: 190 },
  { plan: 'TEAM', name: 'Team', monthly: 49, annual: 490 },
]

function BillingInner() {
  const { data } = useQuery({ queryKey: ['dashboard'], queryFn: () => api.get<{ subscription: Sub; plan: string }>('/dashboard') })

  async function checkout(plan: 'PRO' | 'TEAM', interval: 'month' | 'year') {
    const res = await api.post<{ url: string }>('/billing/checkout', { plan, interval })
    if (res.url) window.location.href = res.url
  }
  async function portal() {
    const res = await api.post<{ url: string }>('/billing/portal')
    if (res.url) window.location.href = res.url
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Billing</h1>
      <Card>
        <CardHeader><CardTitle>Current plan</CardTitle></CardHeader>
        <CardContent className="flex items-center gap-3">
          <Badge variant={data?.plan === 'FREE' ? 'secondary' : 'success'}>{data?.plan}</Badge>
          {data?.subscription?.status && <span className="text-sm text-muted-foreground">{data.subscription.status}</span>}
          {data?.plan !== 'FREE' && <Button size="sm" variant="outline" onClick={portal}>Manage subscription</Button>}
        </CardContent>
      </Card>
      <div className="grid gap-4 md:grid-cols-2">
        {PLANS.map((p) => (
          <Card key={p.plan}>
            <CardHeader><CardTitle>{p.name}</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <p className="text-3xl font-bold">${p.monthly}<span className="text-base font-normal text-muted-foreground">/mo</span></p>
              <div className="flex gap-2">
                <Button className="flex-1" onClick={() => checkout(p.plan, 'month')}>Monthly</Button>
                <Button className="flex-1" variant="outline" onClick={() => checkout(p.plan, 'year')}>Annual (${p.annual})</Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

export default function BillingPage() {
  return <Suspense><BillingInner /></Suspense>
}
