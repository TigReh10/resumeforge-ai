'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { ResumeSelect } from '@/components/dashboard/resume-select'
import { api, ApiError } from '@/lib/api-client'
import { scoreColor } from '@/lib/utils'
import { useToast } from '@/components/ui/toast'

type Analysis = {
  score: number
  result: {
    overallScore: number
    sectionScores: Record<string, number>
    missingSkills: string[]
    recommendations: { priority: string; title: string; detail: string }[]
    summary: string
  }
}

export default function AnalyzePage() {
  const push = useToast((s) => s.push)
  const [resumeId, setResumeId] = useState('')
  const [loading, setLoading] = useState(false)
  const [analysis, setAnalysis] = useState<Analysis | null>(null)

  async function run() {
    if (!resumeId) return
    setLoading(true)
    setAnalysis(null)
    try {
      const res = await api.post<Analysis>('/ai/analyze', { resumeId })
      setAnalysis(res)
    } catch (err) {
      push({ title: 'Analysis failed', description: err instanceof ApiError ? err.message : '', variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const r = analysis?.result
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">ATS Analyzer</h1>
      <Card>
        <CardContent className="flex flex-col gap-3 pt-6 sm:flex-row sm:items-end">
          <div className="flex-1"><ResumeSelect value={resumeId} onChange={setResumeId} /></div>
          <Button onClick={run} disabled={!resumeId || loading}>{loading ? 'Analyzing…' : 'Analyze'}</Button>
        </CardContent>
      </Card>

      {r && (
        <div className="grid gap-6 lg:grid-cols-3">
          <Card className="lg:col-span-1">
            <CardHeader><CardTitle>Overall Score</CardTitle></CardHeader>
            <CardContent className="text-center">
              <p className={`text-6xl font-extrabold ${scoreColor(r.overallScore)}`}>{r.overallScore}</p>
              <p className="mt-2 text-sm text-muted-foreground">{r.summary}</p>
            </CardContent>
          </Card>
          <Card className="lg:col-span-2">
            <CardHeader><CardTitle>Section Scores</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(r.sectionScores).map(([k, v]) => (
                <div key={k}>
                  <div className="mb-1 flex justify-between text-sm"><span className="capitalize">{k.replace(/([A-Z])/g, ' $1')}</span><span className={scoreColor(v)}>{v}</span></div>
                  <Progress value={v} />
                </div>
              ))}
            </CardContent>
          </Card>
          <Card className="lg:col-span-3">
            <CardHeader><CardTitle>Recommendations</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {r.recommendations.map((rec, i) => (
                <div key={i} className="rounded-lg border p-3">
                  <div className="flex items-center gap-2">
                    <Badge variant={rec.priority === 'high' ? 'destructive' : rec.priority === 'medium' ? 'warning' : 'secondary'}>{rec.priority}</Badge>
                    <span className="font-medium">{rec.title}</span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{rec.detail}</p>
                </div>
              ))}
              {r.missingSkills?.length > 0 && (
                <div>
                  <p className="mb-2 text-sm font-medium">Missing skills</p>
                  <div className="flex flex-wrap gap-2">
                    {r.missingSkills.map((s) => <Badge key={s} variant="outline">{s}</Badge>)}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
