'use client'

import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { api } from '@/lib/api-client'
import { formatDate } from '@/lib/utils'

type Application = {
  id: string
  stage: string
  matchScore: number | null
  updatedAt: string
  jobPosting?: { title: string; company?: string }
  resume?: { title: string }
}

const STAGES = ['SAVED', 'APPLIED', 'INTERVIEWING', 'OFFER', 'REJECTED']

export default function ApplicationsPage() {
  const { data } = useQuery({ queryKey: ['applications'], queryFn: () => api.get<Application[]>('/applications') })

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Applications</h1>
      <div className="grid gap-4 md:grid-cols-5">
        {STAGES.map((stage) => (
          <div key={stage} className="space-y-3">
            <h2 className="text-sm font-semibold text-muted-foreground">{stage}</h2>
            {data?.filter((a) => a.stage === stage).map((a) => (
              <Card key={a.id}>
                <CardHeader className="pb-2"><CardTitle className="text-sm">{a.jobPosting?.title ?? 'Role'}</CardTitle></CardHeader>
                <CardContent className="space-y-1">
                  <p className="text-xs text-muted-foreground">{a.jobPosting?.company}</p>
                  {a.matchScore != null && <Badge variant="success">{a.matchScore}% match</Badge>}
                  <p className="text-[10px] text-muted-foreground">{formatDate(a.updatedAt)}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
