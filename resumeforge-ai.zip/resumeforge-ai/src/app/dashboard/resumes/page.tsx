'use client'

import { useRef, useState } from 'react'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { api, ApiError } from '@/lib/api-client'
import { useToast } from '@/components/ui/toast'
import { formatDate } from '@/lib/utils'

type Resume = { id: string; title: string; fileType: string; fileSize: number; updatedAt: string }

export default function ResumesPage() {
  const qc = useQueryClient()
  const push = useToast((s) => s.push)
  const fileRef = useRef<HTMLInputElement>(null)
  const [uploading, setUploading] = useState(false)
  const { data: resumes } = useQuery({ queryKey: ['resumes'], queryFn: () => api.get<Resume[]>('/resumes') })

  async function upload(file: File) {
    setUploading(true)
    try {
      const form = new FormData()
      form.append('file', file)
      form.append('title', file.name.replace(/\.[^.]+$/, ''))
      await api.post('/resumes', form)
      push({ title: 'Resume uploaded', variant: 'success' })
      qc.invalidateQueries({ queryKey: ['resumes'] })
    } catch (err) {
      push({ title: 'Upload failed', description: err instanceof ApiError ? err.message : '', variant: 'error' })
    } finally {
      setUploading(false)
    }
  }

  async function remove(id: string) {
    await api.del(`/resumes/${id}`)
    qc.invalidateQueries({ queryKey: ['resumes'] })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">My Resumes</h1>
        <Button onClick={() => fileRef.current?.click()} disabled={uploading}>
          {uploading ? 'Uploading…' : 'Upload resume'}
        </Button>
        <input
          ref={fileRef}
          type="file"
          accept=".pdf,.docx,.txt"
          className="hidden"
          onChange={(e) => e.target.files?.[0] && upload(e.target.files[0])}
        />
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {resumes?.map((r) => (
          <Card key={r.id}>
            <CardContent className="flex flex-col gap-2 pt-6">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">{r.title}</h3>
                <Badge variant="secondary">{r.fileType}</Badge>
              </div>
              <p className="text-xs text-muted-foreground">Updated {formatDate(r.updatedAt)} · {(r.fileSize / 1024).toFixed(0)} KB</p>
              <div className="mt-2 flex gap-2">
                <Button size="sm" variant="outline" onClick={() => remove(r.id)}>Delete</Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {resumes?.length === 0 && <p className="text-sm text-muted-foreground">No resumes yet. Upload your first one!</p>}
      </div>
    </div>
  )
}
