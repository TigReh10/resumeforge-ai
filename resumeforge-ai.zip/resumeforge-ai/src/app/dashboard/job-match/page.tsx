'use client'

import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { ResumeSelect } from '@/components/dashboard/resume-select'
import { api, ApiError } from '@/lib/api-client'
import { scoreColor } from '@/lib/utils'
import { useToast } from '@/components/ui/toast'

type Match = {
  score: number
  result: {
    matchPercentage: number
    matchedKeywords: string[]
    missingKeywords: string[]
    missingSkills: string[]
    suggestedEdits: { section: string; suggestion: string }[]
    recruiterView: string
    verdict: string
  }
}

export default function JobMatchPage() {
  const qc = useQueryClient()
  const push = useToast((s) => s.push)
  const [resumeId, setResumeId] = useState('')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [loading, setLoading] = useState(false)
  const [match, setMatch] = useState<Match | null>(null)

  async function run() {
    if (!resumeId || description.length < 20) return
    setLoading(true)
    setMatch(null)
    try {
      const job = await api.post<{ id: string }>('/jobs', { title: title || 'Untitled role', description })
      qc.invalidateQueries({ queryKey: ['jobs'] })
      const res = await api.post<Match>('/ai/job-match', { resumeId, jobPostingId: job.id })
      setMatch(res)
    } catch (err) {
      push({ title: 'Match failed', description: err instanceof ApiError ? err.message : '', variant: 'error' })
    } finally {
      setLoading(false)
    }
  }

  const r = match?.result
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Job Match Engine</h1>
      <Card>
        <CardContent className="space-y-3 pt-6">
          <ResumeSelect value={resumeId} onChange={setResumeId} />
          <div className="space-y-2"><Label>Job title</Label><Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Senior Frontend Engineer" /></div>
          <div className="space-y-2"><Label>Job description</Label><Textarea value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Paste the full job description…" className="min-h-[160px]" /></div>
          <Button onClick={run} disabled={!resumeId || description.length < 20 || loading}>{loading ? 'Matching…' : 'Calculate match'}</Button>
        </CardContent>
      </Card>

      {r && (
        <div className="grid gap-6 lg:grid-cols-3">
          <Card>
            <CardHeader><CardTitle>Match</CardTitle></CardHeader>
            <CardContent className="text-center">
              <p className={`text-6xl font-extrabold ${scoreColor(r.matchPercentage)}`}>{r.matchPercentage}%</p>
              <Badge className="mt-2" variant={r.verdict === 'strong' ? 'success' : r.verdict === 'moderate' ? 'warning' : 'destructive'}>{r.verdict}</Badge>
              <Progress className="mt-3" value={r.matchPercentage} />
            </CardContent>
          </Card>
          <Card className="lg:col-span-2">
            <CardHeader><CardTitle>Recruiter view</CardTitle></CardHeader>
            <CardContent><p className="text-sm text-muted-foreground">{r.recruiterView}</p></CardContent>
          </Card>
          <Card className="lg:col-span-3">
            <CardHeader><CardTitle>Keyword gaps &amp; edits</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="mb-2 text-sm font-medium">Missing keywords</p>
                <div className="flex flex-wrap gap-2">{r.missingKeywords.map((k) => <Badge key={k} variant="destructive">{k}</Badge>)}</div>
              </div>
              <div className="space-y-2">
                {r.suggestedEdits.map((e, i) => (
                  <div key={i} className="rounded-lg border p-3"><p className="text-sm font-medium">{e.section}</p><p className="text-sm text-muted-foreground">{e.suggestion}</p></div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
