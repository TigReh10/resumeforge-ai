'use client'

import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { api } from '@/lib/api-client'
import { scoreColor } from '@/lib/utils'

type DashboardData = {
  resumeCount: number
  applicationCount: number
  latestAts: number | null
  atsTrend: { score: number; date: string }[]
  funnel: Record<string, number>
  plan: string
}

export default function DashboardOverview() {
  const { data } = useQuery({ queryKey: ['dashboard'], queryFn: () => api.get<DashboardData>('/dashboard') })

  const stages = ['SAVED', 'APPLIED', 'INTERVIEWING', 'OFFER', 'REJECTED']

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Overview</h1>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Resumes</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold">{data?.resumeCount ?? '—'}</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Applications</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold">{data?.applicationCount ?? '—'}</p></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Latest ATS Score</CardTitle></CardHeader>
          <CardContent>
            <p className={`text-3xl font-bold ${scoreColor(data?.latestAts)}`}>{data?.latestAts ?? '—'}</p>
            {data?.latestAts != null && <Progress className="mt-2" value={data.latestAts} />}
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm text-muted-foreground">Plan</CardTitle></CardHeader>
          <CardContent><p className="text-3xl font-bold">{data?.plan ?? '—'}</p></CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader><CardTitle>ATS Score Trend</CardTitle></CardHeader>
        <CardContent>
          {data?.atsTrend?.length ? (
            <div className="flex h-40 items-end gap-2">
              {data.atsTrend.map((p, i) => (
                <div key={i} className="flex flex-1 flex-col items-center gap-1">
                  <div className="w-full rounded-t bg-primary/80" style={{ height: `${p.score}%` }} title={`${p.score}`} />
                  <span className="text-[10px] text-muted-foreground">{p.score}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Run an ATS analysis to see your score trend.</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Application Funnel</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-5 gap-2 text-center">
            {stages.map((s) => (
              <div key={s} className="rounded-lg bg-muted p-3">
                <p className="text-2xl font-bold">{data?.funnel?.[s] ?? 0}</p>
                <p className="text-xs text-muted-foreground">{s}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
