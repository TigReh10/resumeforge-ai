'use client'

import { useEffect, useState, Suspense } from 'react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { AuthCard } from '@/components/auth/auth-card'
import { api } from '@/lib/api-client'

function Verifier() {
  const params = useSearchParams()
  const [status, setStatus] = useState<'pending' | 'ok' | 'error'>('pending')

  useEffect(() => {
    const token = params.get('token')
    if (!token) {
      setStatus('error')
      return
    }
    api
      .post('/auth/verify-email', { token })
      .then(() => setStatus('ok'))
      .catch(() => setStatus('error'))
  }, [params])

  if (status === 'pending') return <p className="text-center text-sm text-muted-foreground">Verifying…</p>
  if (status === 'ok')
    return (
      <p className="text-center text-sm">
        Your email is verified. <Link className="text-primary" href="/login">Log in</Link>
      </p>
    )
  return <p className="text-center text-sm text-destructive">This verification link is invalid or expired.</p>
}

export default function VerifyEmailPage() {
  return (
    <AuthCard title="Email verification">
      <Suspense>
        <Verifier />
      </Suspense>
    </AuthCard>
  )
}
