import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

const FEATURES = [
  { title: 'ATS Score Analyzer', desc: 'Instant compatibility scoring across formatting, keywords, readability, and more.', icon: '📊' },
  { title: 'Job Match Engine', desc: 'See your match %, missing keywords, and a simulated recruiter first impression.', icon: '🎯' },
  { title: 'AI Resume Builder', desc: 'Drag-and-drop editor, live preview, multiple templates, PDF & DOCX export.', icon: '✍️' },
  { title: 'Cover Letters', desc: 'Tailored, multi-tone cover letters generated from your resume and a job post.', icon: '✉️' },
  { title: 'LinkedIn Optimizer', desc: 'Punch up your headline, about, and skills to get found by recruiters.', icon: '🔗' },
  { title: 'Interview Prep', desc: 'Behavioral & technical questions with suggested answers, tailored to the role.', icon: '🎙️' },
]

const PLANS = [
  { name: 'Free', price: '$0', tagline: 'Get started', features: ['3 resumes', '15 AI actions / mo', 'ATS scoring', 'Job matching'], cta: 'Start free' },
  { name: 'Pro', price: '$19', tagline: 'For active job seekers', features: ['50 resumes', '500 AI actions / mo', 'All AI features', 'Cover letters & rewrites', 'Priority processing'], cta: 'Go Pro', featured: true },
  { name: 'Team', price: '$49', tagline: 'For career coaches & teams', features: ['Unlimited resumes', 'Unlimited AI actions', 'Admin dashboard', 'Usage analytics', 'Priority support'], cta: 'Start Team' },
]

export default function LandingPage() {
  return (
    <main className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
          <Link href="/" className="text-lg font-bold">Resume<span className="text-primary">Forge</span> AI</Link>
          <nav className="flex items-center gap-2">
            <Button asChild variant="ghost"><Link href="/login">Log in</Link></Button>
            <Button asChild><Link href="/register">Get started</Link></Button>
          </nav>
        </div>
      </header>

      <section className="mx-auto flex max-w-4xl flex-col items-center px-4 py-24 text-center">
        <Badge variant="secondary" className="mb-4">Powered by GPT-4o &amp; Claude</Badge>
        <h1 className="text-balance text-5xl font-extrabold tracking-tight sm:text-6xl">
          Build a resume that <span className="text-primary">gets you hired</span>
        </h1>
        <p className="mt-6 max-w-2xl text-lg text-muted-foreground">
          ResumeForge AI scores your resume against ATS systems, matches it to any job, and rewrites it to win interviews — in seconds.
        </p>
        <div className="mt-8 flex gap-3">
          <Button asChild size="lg"><Link href="/register">Analyze my resume free</Link></Button>
          <Button asChild size="lg" variant="outline"><Link href="#features">See features</Link></Button>
        </div>
      </section>

      <section id="features" className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="mb-10 text-center text-3xl font-bold">Everything you need to land the job</h2>
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f) => (
            <Card key={f.title}>
              <CardContent className="pt-6">
                <div className="text-3xl">{f.icon}</div>
                <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{f.desc}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section id="pricing" className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="mb-10 text-center text-3xl font-bold">Simple, transparent pricing</h2>
        <div className="grid gap-6 lg:grid-cols-3">
          {PLANS.map((p) => (
            <Card key={p.name} className={p.featured ? 'border-primary shadow-lg' : ''}>
              <CardContent className="pt-6">
                {p.featured && <Badge className="mb-2">Most popular</Badge>}
                <h3 className="text-xl font-bold">{p.name}</h3>
                <p className="text-sm text-muted-foreground">{p.tagline}</p>
                <p className="mt-4 text-4xl font-extrabold">{p.price}<span className="text-base font-normal text-muted-foreground">/mo</span></p>
                <ul className="mt-6 space-y-2 text-sm">
                  {p.features.map((x) => (<li key={x} className="flex items-center gap-2"><span className="text-primary">✓</span>{x}</li>))}
                </ul>
                <Button asChild className="mt-6 w-full" variant={p.featured ? 'default' : 'outline'}>
                  <Link href="/register">{p.cta}</Link>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <footer className="border-t py-10 text-center text-sm text-muted-foreground">
        © {new Date().getFullYear()} ResumeForge AI. All rights reserved.
      </footer>
    </main>
  )
}
