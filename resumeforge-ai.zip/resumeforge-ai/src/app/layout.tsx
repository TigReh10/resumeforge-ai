import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { Providers } from './providers'

const inter = Inter({ subsets: ['latin'], variable: '--font-sans' })

export const metadata: Metadata = {
  title: { default: 'ResumeForge AI — Land more interviews', template: '%s — ResumeForge AI' },
  description:
    'AI-powered resume optimization, ATS scoring, job matching, cover letters, and interview prep. Build a resume that gets you hired.',
  keywords: ['resume', 'ATS', 'AI resume builder', 'cover letter', 'job match', 'career'],
  openGraph: { title: 'ResumeForge AI', description: 'Build a resume that gets you hired.', type: 'website' },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} font-sans`}>
        <Providers>{children}</Providers>
      </body>
    </html>
  )
}
