import { NextResponse, type NextRequest } from 'next/server'

/**
 * Edge middleware:
 *  - Adds a per-request nonce/request id
 *  - CSRF origin check for state-changing API requests
 *  - Lightweight protection of /dashboard & /admin (presence of access cookie)
 *
 * Deep verification (JWT signature, role) happens in route handlers/server
 * components via getCurrentUser(); middleware only does cheap gating because
 * the JWT secret is not exposed at the edge.
 */
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS'])

export function middleware(req: NextRequest) {
  const { pathname, origin } = req.nextUrl

  // CSRF: for mutating API calls, require same-origin (cookie-based auth).
  if (pathname.startsWith('/api') && !SAFE_METHODS.has(req.method)) {
    // Stripe webhook authenticates via signature, not cookies — skip origin check.
    if (!pathname.startsWith('/api/webhooks/')) {
      const reqOrigin = req.headers.get('origin')
      if (reqOrigin && reqOrigin !== origin) {
        return NextResponse.json({ error: { code: 'csrf', message: 'Cross-origin request blocked' } }, { status: 403 })
      }
    }
  }

  // Gate app areas on presence of an access cookie.
  const hasAccess = req.cookies.has('rf_access')
  if ((pathname.startsWith('/dashboard') || pathname.startsWith('/admin')) && !hasAccess) {
    const url = req.nextUrl.clone()
    url.pathname = '/login'
    url.searchParams.set('next', pathname)
    return NextResponse.redirect(url)
  }

  const res = NextResponse.next()
  res.headers.set('x-request-id', crypto.randomUUID())
  return res
}

export const config = {
  matcher: ['/api/:path*', '/dashboard/:path*', '/admin/:path*'],
}
