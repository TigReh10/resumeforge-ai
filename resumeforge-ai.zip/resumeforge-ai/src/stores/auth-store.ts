'use client'

import { create } from 'zustand'

export type CurrentUser = {
  id: string
  email: string
  name?: string | null
  avatarUrl?: string | null
  role: 'USER' | 'ADMIN'
  planTier: 'FREE' | 'PRO' | 'TEAM'
  emailVerified?: string | null
  twoFactorEnabled?: boolean
}

type AuthState = {
  user: CurrentUser | null
  setUser: (user: CurrentUser | null) => void
  clear: () => void
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  setUser: (user) => set({ user }),
  clear: () => set({ user: null }),
}))
