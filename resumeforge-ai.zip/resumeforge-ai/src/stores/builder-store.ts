'use client'

import { create } from 'zustand'

export type ResumeSection = {
  id: string
  type: 'summary' | 'experience' | 'education' | 'skills' | 'projects' | 'custom'
  title: string
  content: string
}

type BuilderState = {
  title: string
  template: 'modern' | 'classic' | 'minimal' | 'technical'
  sections: ResumeSection[]
  setTitle: (title: string) => void
  setTemplate: (t: BuilderState['template']) => void
  setSections: (s: ResumeSection[]) => void
  updateSection: (id: string, content: string) => void
  reorder: (from: number, to: number) => void
  addSection: (type: ResumeSection['type']) => void
  removeSection: (id: string) => void
}

export const useBuilderStore = create<BuilderState>((set) => ({
  title: 'My Resume',
  template: 'modern',
  sections: [
    { id: 'summary', type: 'summary', title: 'Summary', content: '' },
    { id: 'experience', type: 'experience', title: 'Experience', content: '' },
    { id: 'education', type: 'education', title: 'Education', content: '' },
    { id: 'skills', type: 'skills', title: 'Skills', content: '' },
  ],
  setTitle: (title) => set({ title }),
  setTemplate: (template) => set({ template }),
  setSections: (sections) => set({ sections }),
  updateSection: (id, content) =>
    set((s) => ({ sections: s.sections.map((sec) => (sec.id === id ? { ...sec, content } : sec)) })),
  reorder: (from, to) =>
    set((s) => {
      const next = [...s.sections]
      const [moved] = next.splice(from, 1)
      next.splice(to, 0, moved)
      return { sections: next }
    }),
  addSection: (type) =>
    set((s) => ({
      sections: [
        ...s.sections,
        { id: `${type}-${Date.now()}`, type, title: type[0].toUpperCase() + type.slice(1), content: '' },
      ],
    })),
  removeSection: (id) => set((s) => ({ sections: s.sections.filter((sec) => sec.id !== id) })),
}))
