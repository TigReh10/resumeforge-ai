# ResumeForge AI

Production-ready, scalable SaaS for AI-powered resume optimization: ATS scoring, job matching, resume building, cover letters, LinkedIn optimization, interview prep, skill-gap analysis, and career roadmaps.

Built with **Next.js 14 (App Router)**, **TypeScript**, **Tailwind + shadcn-style UI**, **Prisma + PostgreSQL**, **Redis + BullMQ**, **Stripe**, **S3-compatible storage**, and a **multi-provider AI layer (OpenAI + Anthropic with fallback & streaming)**.

---

## Features

| Area | Capabilities |
|------|--------------|
| **Resume Analyzer** | ATS compatibility score, section-by-section scoring, missing keywords, prioritized recommendations |
| **Resume Builder** | Drag-and-drop sections, 4 templates, live preview, TXT/print-to-PDF export, version history |
| **Job Match Engine** | Match %, matched/missing keywords, recruiter-view simulation, suggested edits |
| **Cover Letters** | Tailored, multi-tone generation from resume + job description |
| **LinkedIn Optimizer** | Improved headline & about, recruiter discoverability tips |
| **Interview Prep** | Behavioral + technical questions with suggested answers and follow-ups |
| **Skill-Gap & Career Roadmap** | Readiness score, gap closing plan, milestone roadmap |
| **Dashboard** | Stats, ATS trend, application funnel (Kanban) |
| **Admin Panel** | User management, role/suspend control, MRR & usage analytics, audit log |
| **Billing** | Stripe subscriptions (monthly + annual), usage limits, webhooks |
| **Auth** | Email/password, email verification, password reset, Google OAuth, TOTP 2FA with recovery codes |
| **Security** | Rate limiting, CSRF protection, secure uploads (magic-byte checks), encryption at rest, audit logging, security headers/CSP |

---

## Quick start (local)

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env   # then fill in secrets

# 3. Start infrastructure (Postgres + Redis) and the app
docker compose up -d postgres redis
npx prisma migrate deploy
npx prisma db seed

# 4. Run the dev server + the background worker
npm run dev          # web app on http://localhost:3000
npm run worker       # BullMQ worker for heavy AI jobs
```

Default seeded admin: `admin@resumeforge.ai` / `ChangeMe123!` (override via `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD`).

---

## Full Docker deployment

```bash
docker compose up -d --build
```

This starts: `web` (Next.js standalone), `worker` (BullMQ), `postgres`, and `redis`. Migrations run automatically on the web container's entrypoint.

---

## Scripts

| Script | Description |
|--------|-------------|
| `npm run dev` | Start Next.js dev server |
| `npm run build` | Production build |
| `npm run start` | Start production server |
| `npm run worker` | Start the BullMQ AI worker |
| `npm run lint` | ESLint |
| `npm run typecheck` | `tsc --noEmit` |
| `npm run test` | Vitest unit + integration tests |
| `npm run test:e2e` | Playwright E2E tests |
| `npm run prisma:migrate` | Run Prisma migrations |
| `npm run prisma:seed` | Seed the database |

---

## Project structure

```
src/
  app/                 # Next.js App Router (marketing, auth, dashboard, admin, API routes)
    api/               # REST API route handlers
    (marketing)/       # Public landing page
    (auth)/            # Login, register, reset, verify
    dashboard/         # Authenticated product UI
    admin/             # Admin panel
  components/          # UI (shadcn-style) + feature components
  lib/                 # Core libraries (auth, ai, storage, queue, services, validation)
  server/              # Background worker
  stores/              # Zustand stores
prisma/                # Schema + seed
tests/                 # unit / integration / e2e
```

See [`ARCHITECTURE.md`](./ARCHITECTURE.md) for system design, data model, API surface, and the production setup guide.

---

## Environment variables

See [`.env.example`](./.env.example) for the full list with inline comments. Key groups: database, Redis, JWT secrets, encryption key, Google OAuth, SMTP, S3 storage, OpenAI/Anthropic, and Stripe.

## License

Proprietary — © ResumeForge AI.
