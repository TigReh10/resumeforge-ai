# ResumeForge AI — Architecture

## 1. System overview

```mermaid
flowchart LR
  U["Browser (Next.js App Router)"] -->|HTTPS| W["Next.js Web (API routes + RSC)"]
  W --> PG[("PostgreSQL")]
  W --> R[("Redis")]
  W --> S3["S3-compatible storage"]
  W --> AI["AI layer: OpenAI + Anthropic"]
  W --> ST["Stripe"]
  W -->|enqueue| Q["BullMQ queue (Redis)"]
  Q --> WK["Worker service"]
  WK --> AI
  WK --> PG
  ST -->|webhooks| W
```

- **Web tier** is stateless and horizontally scalable behind a load balancer. Sessions are JWT-based (access + refresh cookies), so no sticky sessions are required.
- **Heavy AI processing** (long generations, batch operations) is offloaded to a **BullMQ** queue consumed by a separate **worker** service, keeping request latency low and enabling independent scaling.
- **Redis** powers rate limiting, caching, and the job queue.
- **PostgreSQL** (via Prisma) is the system of record.
- **S3-compatible storage** holds uploaded resume files (server-side encrypted; access via presigned URLs).

## 2. Data model

```mermaid
erDiagram
  User ||--o{ OAuthAccount : has
  User ||--o{ Session : has
  User ||--o{ Resume : owns
  User ||--o{ JobPosting : creates
  User ||--o{ Application : tracks
  User ||--o{ Analysis : runs
  User ||--o{ CoverLetter : generates
  User ||--o{ AiJob : queues
  User ||--|| Subscription : has
  User ||--o{ UsageRecord : accrues
  User ||--o{ AuditLog : emits
  Resume ||--o{ ResumeVersion : has
  Resume ||--o{ Analysis : analyzed_by
  Resume ||--o{ Application : used_in
  JobPosting ||--o{ Application : targeted_by
  JobPosting ||--o{ Analysis : scored_against
  JobPosting ||--o{ CoverLetter : basis_for
```

Key models: `User`, `OAuthAccount`, `Session`, `VerificationToken`, `Resume`, `ResumeVersion`, `JobPosting`, `Application`, `Analysis`, `CoverLetter`, `AiJob`, `Subscription`, `UsageRecord`, `AuditLog`, `WebhookEvent`. Indexes are defined on all foreign keys and on common query paths (e.g. `userId`, `userId+feature+period`, `eventId`).

## 3. API surface

| Group | Endpoints |
|-------|-----------|
| Auth | `POST /api/auth/register`, `login`, `logout`, `refresh`, `GET /api/auth/me`, `verify-email`, `request-reset`, `reset-password`, `2fa/setup|enable|disable`, `google`, `google/callback` |
| Resumes | `GET/POST /api/resumes`, `GET/PATCH/DELETE /api/resumes/[id]` |
| Jobs/Apps | `GET/POST /api/jobs`, `GET/POST /api/applications` |
| AI | `POST /api/ai/analyze`, `job-match`, `cover-letter`, `linkedin`, `interview`, `skill-gap`, `career-roadmap`, `rewrite`, `GET/POST /api/ai/jobs` (async) |
| Billing | `POST /api/billing/checkout`, `portal`, `POST /api/webhooks/stripe` |
| Dashboard | `GET /api/dashboard` |
| Admin | `GET /api/admin/users`, `PATCH /api/admin/users/[id]`, `GET /api/admin/analytics`, `GET /api/admin/audit` |
| System | `GET /api/health` |

All handlers share: zod validation, rate-limit guards (`authed`/`adminOnly`), uniform error envelope (`handleError`), and audit logging on sensitive mutations.

## 4. AI layer

- Provider-agnostic interface (`src/lib/ai`) with **OpenAI** and **Anthropic** adapters.
- **Fallback chain**: the primary provider is tried first; on failure the chain falls through to the secondary. `withRetry` adds exponential backoff.
- **Structured output** via `completeJson` (schema-guided), and **streaming** via `streamComplete`.
- Prompts are centralized in `src/lib/ai/prompts.ts` for auditability and tuning.

## 5. Security

- **Auth**: argon2/scrypt password hashing, JWT (HS256) access + rotating refresh tokens, httpOnly/SameSite cookies, TOTP 2FA with encrypted secrets and recovery codes.
- **Transport/headers**: strict CSP, `X-Frame-Options`, `X-Content-Type-Options`, referrer policy (see `next.config.mjs`).
- **CSRF**: same-origin enforcement in middleware (webhooks exempt and signature-verified instead).
- **Uploads**: extension + magic-byte validation, size caps, server-side encryption, presigned download URLs.
- **Abuse**: Redis fixed-window rate limiting per bucket (auth/ai/upload/default).
- **Data**: field-level encryption for secrets (`src/lib/crypto`), full audit log, GDPR-friendly delete (cascade on user).

## 6. Production setup guide

1. Provision PostgreSQL and Redis (managed services recommended).
2. Create an S3-compatible bucket; set `S3_*` env vars.
3. Configure Stripe products/prices; set `STRIPE_*` (incl. webhook secret) and register the webhook endpoint `/api/webhooks/stripe`.
4. Configure OAuth (Google) and SMTP for transactional email.
5. Set strong `JWT_ACCESS_SECRET`, `JWT_REFRESH_SECRET`, and a 32-byte `ENCRYPTION_KEY`.
6. `docker compose up -d --build` (or deploy `web` + `worker` images to your orchestrator).
7. Run `prisma migrate deploy` and `prisma db seed`.
8. Point a CDN/load balancer at the `web` service; scale `web` and `worker` independently.
9. Wire `SENTRY_DSN` for error tracking and ship logs (pino) to your aggregator.

## 7. Testing strategy

- **Unit** (Vitest): pure logic — crypto, password hashing, JWT, plan limits, upload validation.
- **Integration** (Vitest): zod schemas and route handlers with mocked infrastructure (e.g. `/api/health`).
- **E2E** (Playwright): critical user journeys — landing → register, auth redirects, pricing visibility, SSO presence.
- CI runs lint → typecheck → unit/integration on every push (see `.github/workflows/ci.yml`).
