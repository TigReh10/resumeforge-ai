import { PrismaClient, Role, PlanTier } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  const adminEmail = process.env.SEED_ADMIN_EMAIL || 'admin@resumeforge.ai'
  const adminPassword = process.env.SEED_ADMIN_PASSWORD || 'ChangeMe123!'
  const passwordHash = await bcrypt.hash(adminPassword, 12)

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: { role: Role.ADMIN },
    create: {
      email: adminEmail,
      name: 'Platform Admin',
      passwordHash,
      role: Role.ADMIN,
      planTier: PlanTier.TEAM,
      emailVerified: new Date(),
    },
  })

  // eslint-disable-next-line no-console
  console.log(`Seeded admin: ${admin.email} (password: ${adminPassword})`)
}

main()
  .catch((e) => {
    // eslint-disable-next-line no-console
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
