import { describe, it, expect, beforeAll } from 'vitest'
import { signAccessToken, verifyAccessToken } from '@/lib/auth/jwt'

beforeAll(() => {
  process.env.JWT_ACCESS_SECRET ||= 'test-access-secret-test-access-secret'
  process.env.JWT_REFRESH_SECRET ||= 'test-refresh-secret-test-refresh-secret'
})

describe('jwt access tokens', () => {
  it('signs and verifies an access token', async () => {
    const token = await signAccessToken({ sub: 'user_1', email: 'a@b.co', role: 'USER', plan: 'FREE' })
    const claims = await verifyAccessToken(token)
    expect(claims.sub).toBe('user_1')
    expect(claims.role).toBe('USER')
  })

  it('rejects a tampered token', async () => {
    const token = await signAccessToken({ sub: 'user_1', email: 'a@b.co', role: 'USER', plan: 'FREE' })
    await expect(verifyAccessToken(token + 'x')).rejects.toBeDefined()
  })
})
