import { describe, it, expect } from 'vitest'
import { validateUpload, checksum, naiveStructure, FileValidationError } from '@/lib/resume/parse'

describe('resume upload validation', () => {
  it('accepts a small txt file', () => {
    const buf = Buffer.from('John Doe\nSoftware Engineer')
    expect(() => validateUpload('resume.txt', buf)).not.toThrow()
  })

  it('rejects an oversized file', () => {
    const buf = Buffer.alloc(9 * 1024 * 1024)
    expect(() => validateUpload('resume.txt', buf)).toThrow(FileValidationError)
  })

  it('rejects unsupported extensions', () => {
    expect(() => validateUpload('resume.exe', Buffer.from('x'))).toThrow(FileValidationError)
  })

  it('computes a stable checksum', () => {
    const a = checksum(Buffer.from('abc'))
    const b = checksum(Buffer.from('abc'))
    expect(a).toBe(b)
  })

  it('detects sections in naive structure', () => {
    const s = naiveStructure('EXPERIENCE\nAcme\nEDUCATION\nMIT\nSKILLS\nTypeScript')
    expect(s.sections).toContain('experience')
  })
})
