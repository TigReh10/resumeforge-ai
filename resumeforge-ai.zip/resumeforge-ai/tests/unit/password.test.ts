import { describe, it, expect } from 'vitest'
import { hashPassword, verifyPassword } from '@/lib/auth/password'

describe('password hashing', () => {
  it('hashes and verifies a correct password', async () => {
    const hash = await hashPassword('CorrectHorse9')
    expect(hash).not.toBe('CorrectHorse9')
    expect(await verifyPassword('CorrectHorse9', hash)).toBe(true)
  })

  it('rejects an incorrect password', async () => {
    const hash = await hashPassword('CorrectHorse9')
    expect(await verifyPassword('WrongHorse9', hash)).toBe(false)
  })
})
