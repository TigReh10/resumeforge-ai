import { describe, it, expect } from 'vitest'
import { encrypt, decrypt } from '@/lib/crypto'

describe('crypto encrypt/decrypt', () => {
  it('round-trips a secret value', () => {
    const secret = 'JBSWY3DPEHPK3PXP'
    const enc = encrypt(secret)
    expect(enc).not.toBe(secret)
    expect(decrypt(enc)).toBe(secret)
  })

  it('produces different ciphertext for same input (random IV)', () => {
    expect(encrypt('hello')).not.toBe(encrypt('hello'))
  })
})
