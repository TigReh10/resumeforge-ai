import { describe, it, expect } from 'vitest'
import { PLAN_LIMITS, PLAN_PRICING } from '@/lib/plans'

describe('plan limits', () => {
  it('free plan is the most restrictive', () => {
    expect(PLAN_LIMITS.FREE.resumes).toBeLessThan(PLAN_LIMITS.PRO.resumes)
    expect(PLAN_LIMITS.FREE.aiActions).toBeLessThan(PLAN_LIMITS.PRO.aiActions)
  })

  it('team plan is unlimited', () => {
    expect(PLAN_LIMITS.TEAM.resumes).toBe(-1)
    expect(PLAN_LIMITS.TEAM.aiActions).toBe(-1)
  })

  it('pricing increases with tier', () => {
    expect(PLAN_PRICING.FREE).toBe(0)
    expect(PLAN_PRICING.PRO).toBeLessThan(PLAN_PRICING.TEAM)
  })
})
