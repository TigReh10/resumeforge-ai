import { test, expect } from '@playwright/test'

test('pricing section is visible on landing', async ({ page }) => {
  await page.goto('/#pricing')
  await expect(page.getByRole('heading', { name: /simple, transparent pricing/i })).toBeVisible()
  await expect(page.getByText('Most popular')).toBeVisible()
})

test('login page exposes Google SSO', async ({ page }) => {
  await page.goto('/login')
  await expect(page.getByRole('link', { name: /continue with google/i })).toBeVisible()
})
