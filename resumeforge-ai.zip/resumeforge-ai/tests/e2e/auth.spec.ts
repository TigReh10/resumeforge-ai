import { test, expect } from '@playwright/test'

test.describe('authentication', () => {
  test('landing page renders and links to register', async ({ page }) => {
    await page.goto('/')
    await expect(page.getByRole('heading', { name: /gets you hired/i })).toBeVisible()
    await page.getByRole('link', { name: /get started/i }).first().click()
    await expect(page).toHaveURL(/\/register/)
  })

  test('register form validates required fields', async ({ page }) => {
    await page.goto('/register')
    await expect(page.getByLabel('Email')).toBeVisible()
    await expect(page.getByLabel('Password')).toBeVisible()
    await expect(page.getByRole('button', { name: /create account/i })).toBeVisible()
  })

  test('unauthenticated dashboard redirects to login', async ({ page }) => {
    await page.goto('/dashboard')
    await expect(page).toHaveURL(/\/login/)
  })
})
