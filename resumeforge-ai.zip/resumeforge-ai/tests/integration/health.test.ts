import { describe, it, expect, vi, beforeEach } from 'vitest'

// Mock heavy deps so the route handler can be imported in isolation.
vi.mock('@/lib/prisma', () => ({ prisma: { $queryRaw: vi.fn().mockResolvedValue([{ ok: 1 }]) } }))
vi.mock('@/lib/redis', () => ({ redis: { ping: vi.fn().mockResolvedValue('PONG') } }))
vi.mock('@/lib/ai', () => ({ aiHealth: vi.fn().mockResolvedValue({ openai: true, anthropic: false }) }))

describe('GET /api/health', () => {
  beforeEach(() => vi.clearAllMocks())

  it('returns ok when dependencies are healthy', async () => {
    const { GET } = await import('@/app/api/health/route')
    const res = await GET()
    const body = await res.json()
    expect(res.status).toBe(200)
    expect(body.status).toBe('ok')
    expect(body.checks.database).toBe(true)
    expect(body.checks.redis).toBe(true)
  })
})
