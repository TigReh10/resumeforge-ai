import { describe, it, expect } from 'vitest'
import { registerSchema, loginSchema, analyzeSchema, jobPostingSchema } from '@/lib/validation'

describe('validation schemas', () => {
  it('accepts a valid registration', () => {
    const r = registerSchema.safeParse({ name: 'Jo', email: 'jo@x.co', password: 'Password12' })
    expect(r.success).toBe(true)
  })

  it('rejects weak passwords', () => {
    const r = registerSchema.safeParse({ email: 'jo@x.co', password: 'short' })
    expect(r.success).toBe(false)
  })

  it('rejects invalid email on login', () => {
    expect(loginSchema.safeParse({ email: 'nope', password: 'x' }).success).toBe(false)
  })

  it('requires a resumeId for analyze', () => {
    expect(analyzeSchema.safeParse({}).success).toBe(false)
  })

  it('requires a description for job postings', () => {
    expect(jobPostingSchema.safeParse({ title: 'Dev' }).success).toBe(false)
  })
})
