import { beforeAll } from 'vitest'

beforeAll(() => {
  process.env.JWT_ACCESS_SECRET ||= 'test-access-secret-test-access-secret'
  process.env.JWT_REFRESH_SECRET ||= 'test-refresh-secret-test-refresh-secret'
  process.env.ENCRYPTION_KEY ||= '0123456789abcdef0123456789abcdef'
  process.env.DATABASE_URL ||= 'postgresql://localhost:5432/test'
  process.env.REDIS_URL ||= 'redis://localhost:6379'
  process.env.APP_URL ||= 'http://localhost:3000'
})
